// ════════════════════════════════════════════════════════════════════
//  SETTING.JS — Konfigurasi Lengkap Bot Gojo Satoru MD
//  Edit file ini untuk mengubah seluruh perilaku & tampilan bot.
//  Versi: 3.0.0 — Infinity Edition
// ════════════════════════════════════════════════════════════════════

export const settings = {

    // ╔═══════════════════════════════════════╗
    // ║           IDENTITAS BOT               ║
    // ╚═══════════════════════════════════════╝

    // Nama & nomor Creator TIDAK lagi disimpan di sini — itu sengaja
    // dipindahkan ke lib/roles.js (hardcoded + dilindungi checksum
    // integritas) agar tidak bisa diubah dengan mudah lewat edit file
    // biasa. Untuk menampilkan info Creator di kode, import
    // `getCreatorInfo()` dari '../lib/roles.js'.
    botName:      'Gojo Satoru MD',
    botVersion:   '3.0.0',
    botTagline:   '❄️ Infinity Edition — The Strongest Bot',
    prefix:       '.',

    // Nama Owner UTAMA — cuma dipakai untuk TAMPILAN (misal di .owner,
    // .allmenu, dll). Bebas diganti kapan saja, tidak butuh restart bot
    // untuk berlaku.
    ownerName: 'Owner',

    // Nomor Owner UTAMA (format: 628xxx, tanpa "+", "@s.whatsapp.net",
    // atau spasi). Nomor ini OTOMATIS punya akses Owner penuh — beda
    // dengan `ownerName` di atas yang cuma teks tampilan. Cukup ganti
    // nilainya lalu restart bot untuk berlaku.
    ownerNumber: '',

    // Daftar nomor Owner TAMBAHAN (selain `ownerNumber` di atas, dan
    // selain Creator yang sudah otomatis menjadi Owner). Cukup tulis
    // nomor tanpa "+", "@s.whatsapp.net", atau spasi — contoh:
    // '6281234567890'. Edit array ini langsung untuk menambah/menghapus
    // Owner, lalu restart bot.
    // (Owner juga bisa ditambah saat bot berjalan lewat command
    // `.addowner @tag` — boleh dipakai oleh Owner ATAUPUN Creator, dan
    // langsung aktif tanpa restart, beda dengan `ownerNumber`/
    // `ownerNumbers` di sini yang butuh restart bot setelah diedit.)
    ownerNumbers: [
        // '6281234567890',
        // '6289876543210',
    ],

    // Daftar nomor Premium. Sama formatnya seperti ownerNumbers di atas.
    // Owner dan Creator otomatis mendapat akses Premium juga, jadi tidak
    // perlu didaftarkan ulang di sini.
    premiumNumbers: [
        // '6281234567890',
    ],

    // Nomor HP untuk pairing (format: 628xxx tanpa + atau spasi)
    // Bisa juga diisi lewat ENV variable NOMOR_HP di Pterodactyl.
    // Kalau dua-duanya dikosongkan/dibiarkan placeholder ini, bot akan
    // TANYA langsung lewat console saat startup (lihat promptNomorHP()
    // di index.js) — jadi tidak wajib edit file ini kalau mau isi manual.
    nomorPairing: '628xxxxxxxxxx',

    // URL thumbnail Gojo Satoru (tampil di setiap reply bot)
    thumbnailUrl: 'https://files.catbox.moe/rx8awo.png',

    // URL thumbnail khusus command .daftar (registrasi RPG)
    thumbnailDaftar: 'https://files.catbox.moe/ndtp84.png',

    // URL thumbnail khusus .ryoiken/.tenkai (Ryoiki Tenkai). Cuma dipakai
    // sebagai fallback kalau media/ryoiki-tenkai.mp4 belum di-taruh —
    // lihat commands/adminCommands.js -> ryoikiTenkaiKick().
    thumbnailRyoikiTenkai: 'https://files.catbox.moe/cx8bib.png',


    // ╔═══════════════════════════════════════╗
    // ║      PEMBAYARAN & SOSIAL MEDIA        ║
    // ╚═══════════════════════════════════════╝

    // Nomor e-wallet Owner — ditampilkan lewat command .pembayaran.
    // Ganti nomor di bawah sesuai e-wallet kamu sendiri (boleh beda-beda
    // nomor per e-wallet, tidak harus sama semua). Tidak perlu restart bot
    // untuk berlaku — cukup edit lalu simpan.
    nodana:  '085188426365',
    nogopay: '085188426365',
    noovo:   '085188426365',

    // Sosial media Owner — ditampilkan lewat command .sosmedowner.
    ig:   '@kenjikitagawa',
    tele: 'GojoSatoruOFC',
    yt:   'JanpiwWok',


    // ╔═══════════════════════════════════════╗
    // ║         PERILAKU & FITUR BOT          ║
    // ╚═══════════════════════════════════════╝

    // ── Auto-Read ────────────────────────────────────────────────────
    // Tandai pesan sebagai sudah dibaca (centang biru) sebelum balas
    autoRead:     true,

    // ── Auto-Typing ──────────────────────────────────────────────────
    // Tampilkan indikator "mengetik..." saat memproses command
    autoTyping:   true,
    // v3.1.2: rentang delay "mengetik" sebelum bot membalas (ms) — dibuat
    // acak di antara min–max (bukan angka tetap) biar terkesan lebih
    // manusiawi. Diatur ke 3-4 detik sesuai permintaan.
    typingDurationMin: 3000,
    typingDurationMax: 4000,

    // ── Online Status ─────────────────────────────────────────────────
    // true  = bot terlihat Online (bisa menguras baterai HP)
    // false = bot diam-diam berjalan (direkomendasikan)
    markOnlineOnConnect: false,

    // ── Self-Bot Mode ─────────────────────────────────────────────────
    // Jika true, bot HANYA merespons pesan dari owner sendiri
    selfMode: false,

    // ── Footer Pesan ──────────────────────────────────────────────────
    // Teks yang muncul di bawah setiap reply (kosongkan jika tidak mau)
    replyFooter: '',


    // ╔═══════════════════════════════════════╗
    // ║         SISTEM COOLDOWN               ║
    // ╚═══════════════════════════════════════╝

    // Aktifkan sistem cooldown per user per command
    cooldownEnabled: true,
    // Jeda default antar command yang sama (ms) — 3 detik
    defaultCooldown: 3000,
    // Override per kategori (ms)
    cooldowns: {
        rpg:   8000,   // Command RPG (hunt, boss, dungeon, dll) — 8 detik
        admin: 2000,   // Command admin grup
        fun:   3000,   // Fun & game
        tools: 1500,   // Tools & kalkulator
        menu:   500,   // Menu & info
    },
    // Owner bypass cooldown
    ownerBypassCooldown: true,


    // ╔═══════════════════════════════════════╗
    // ║       RECONNECT & KONEKSI             ║
    // ╚═══════════════════════════════════════╝

    // Jeda awal sebelum reconnect pertama (detik)
    reconnectDelay: 5,
    // Delay eksponensial: setiap gagal, delay × faktor ini (max reconnectDelayMax)
    reconnectBackoffFactor: 1.5,
    // Delay maksimum reconnect (detik)
    reconnectDelayMax: 60,
    // 0 = coba reconnect selamanya
    maxReconnectAttempts: 0,

    // Seberapa sering folder session/ di-backup otomatis ke session-backup/
    // (menit). Backup hanya terjadi setelah koneksi berhasil terbuka, dan
    // hanya kalau session/ dalam keadaan valid (ada creds.json) — lihat
    // backupSession() di index.js untuk detail lengkap kenapa ini membantu
    // mengatasi masalah "session sering rusak" (badSession).
    sessionBackupIntervalMinutes: 30,


    // ╔═══════════════════════════════════════╗
    // ║         PROTEKSI GRUP                 ║
    // ╚═══════════════════════════════════════╝

    // Jumlah pesan maks dalam satu window sebelum dianggap spam
    spamMaxMessages: 6,
    // Durasi window spam (ms)
    spamWindowMs: 10_000,
    // Jumlah warn sebelum auto-kick (per default, bisa diubah per grup)
    defaultWarnLimit: 3,

    // ── Kata Toxic Default ────────────────────────────────────────────
    // Daftar kata yang diblokir anti-toxic (selain hardcoded)
    // Tambah kata-kata lain di sini sesuai kebutuhan grupmu
    extraToxicWords: [],


    // ╔═══════════════════════════════════════╗
    // ║             LOGGING                   ║
    // ╚═══════════════════════════════════════╝

    // Tampilkan log setiap pesan masuk di console
    logMessages:  true,
    // Tampilkan log setiap command dijalankan
    logCommands:  true,
    // Log level Baileys — 'silent' hampir selalu yang terbaik untuk prod
    baileysLogLevel: 'silent',

};

export default settings;
