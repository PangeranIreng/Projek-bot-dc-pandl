import { rpgCommands } from './rpgCommands.js';
import { recallRealJid } from '../lib/lidMapping.js';
import { rpgCommands2 } from './rpgCommands2.js';
import { rpgCommands3 } from './rpgCommands3.js';
import { rpgCommands4 } from './rpgCommands4.js';
import { rpgCommands5 } from './rpgCommands5.js';
import { adminCommands, checkMute, isGroupLocked } from './adminCommands.js';
import { adminCommands2 } from './adminCommands2.js';
import { adminCommands3 } from './adminCommands3.js';
import { adminCommands4 } from './adminCommands4.js';
import { funCommands } from './funCommands.js';
import { funCommands2 } from './funCommands2.js';
import { funCommands3 } from './funCommands3.js';
import { textTools, mathTools, converterTools, generatorTools, infoTools } from './toolsCommands.js';
import { mathTools2, dateTools, formatTools, validatorTools } from './toolsCommands2.js';
import { toolsCommands3 } from './toolsCommands3.js';
import { mediaCommands } from './mediaCommands.js';
import { gojoCommands } from './gojoCommands.js';
import { broadcastCommands } from './broadcastCommands.js';
import { jadibotCommands } from './jadibotCommands.js';
import { musicCommands } from './musicCommands.js';
import { socialDownloadCommands } from './socialDownloadCommands.js';
import { trackCommand, countUsers, countGroups, getTotalCommandsRan, getTopCommands } from '../lib/db.js';
import { fmtDuration, safeReplyText, withTimeout, fmtTime, fmtDate, isLidJid } from '../lib/utils.js';
import { isCreator, isOwner, isPremium, listOwners, listPremium, getRoleLabel, getCreatorInfo, addOwner, removeOwner, addPremium, removePremium, isCoCreator, listCoCreators, addCoCreator, removeCoCreator } from '../lib/roles.js';
import { checkMediaLimit, consumeMediaLimit, buyMediaLimit, addLimitManual, limitStatusText } from '../lib/mediaLimit.js';
import { getChar, saveChar } from '../lib/rpgEngine.js';
import { isAutoread, setAutoread, isAutotyping, setAutotyping } from '../lib/autoFeatures.js';
import { isGojoAiEnabled, setGojoAiEnabled } from '../lib/gojoAi.js';
import { store, save } from '../lib/db.js';
import { sewaCommands } from './sewaCommands.js';
import { bratGenerate, iqc } from './bratCommands.js';
import { checkSewaExpiry, isSewaActive, isSewaMode } from '../lib/sewaBot.js';

// ── Runtime bot config (selfMode dll) — persist ke db ───────────────────────
function botCfg() { return store('botConfig', { selfMode: false, autojoin: true }); }
function saveBotCfg() { save('botConfig'); }

// Load saved config saat startup (mutasi settings langsung)
;(() => {
    const cfg = botCfg();
    if (typeof cfg.selfMode === 'boolean') settings.selfMode = cfg.selfMode;
    if (typeof cfg.public  === 'boolean') settings.public   = cfg.public;
})();
import { log } from '../lib/logger.js';
import { sendMainMenu, sendAdminMenu, sendFunMenu, sendToolsMenu, sendMediaMenu, sendBotMenu, sendRpgMenu } from './menu.js';
import settings from '../setting.js';
import { parseDaftarInput, register, getProfile, isRegistered } from '../lib/registry.js';

const BOT_START_TIME = Date.now();

// ─── REPLY (PLAIN TEXT) ───────────────────────────────────────────────────
// CATATAN: fitur thumbnail/externalAdReply yang sebelumnya ada di sini
// SUDAH DIHAPUS. Penyebabnya: ditemukan error nyata di lapangan —
//   "The value of "value" is out of range. It must be >= 0 and <= 255"
// — yang terjadi spesifik saat mengirim externalAdReply ke JID berformat
// @lid (format "Linked ID" baru yang dipakai WhatsApp untuk beberapa
// akun/grup). Error ini membuat SESSION BAILEYS RUSAK TOTAL ("Session
// rusak. Auto-reset...", lalu "Session lama dihapus otomatis"), yang
// kemungkinan besar adalah akar dari masalah command yang gagal total
// tanpa balasan ATAUPUN error yang kita selidiki sebelumnya — bukan
// sekadar 1 pesan gagal, tapi seluruh sesi koneksi ke WhatsApp jadi
// tidak sehat setelahnya. Karena risiko ini (crash + corrupt session)
// jauh lebih besar daripada manfaat kosmetik sebuah thumbnail, fitur ini
// dihapus sepenuhnya, bukan sekadar diberi try/catch tambahan.
async function replyWithThumb(sock, jid, text, quotedMsg) {
    text = safeReplyText(text);
    try {
        return await withTimeout(sock.sendMessage(jid, { text }, { quoted: quotedMsg }), 30_000, 'sendMessage(plainText)');
    } catch (err) {
        log.error(`GAGAL kirim pesan ke ${jid}: ${err.message}`);
        throw err;
    }
}

// ─── REPLY DENGAN GAMBAR (thumbnail khusus per-command) ────────────────────
// PENTING: ini BEDA dengan externalAdReply yang dihapus di atas — ini kirim
// gambar biasa (message `image`, persis pola settings.thumbnailUrl yang
// sudah dipakai di .menu & .allmenu), BUKAN link-preview ad-reply. Jadi
// tidak memicu bug @lid yang dulu bikin session corrupt. Selalu fallback
// ke teks biasa (replyWithThumb) kalau kirim gambar gagal.
export async function replyWithImage(sock, jid, quotedMsg, imageUrl, text) {
    if (imageUrl) {
        try {
            await withTimeout(
                sock.sendMessage(jid, { image: { url: imageUrl }, caption: safeReplyText(text) }, { quoted: quotedMsg }),
                30_000,
                'sendMessage(image)'
            );
            return;
        } catch (err) {
            log.error(`Gagal kirim gambar thumbnail ke ${jid}: ${err.message}`);
            // lanjut ke fallback teks biasa di bawah
        }
    }
    await replyWithThumb(sock, jid, text, quotedMsg);
}

function getMentioned(msg) {
    return msg.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
}

// ─── COMMAND TABLE ──────────────────────────────────────────────────────
// Each entry: [aliases[], handler(ctx)]
// ctx = { sock, msg, jid, sender, args, isGroup, body, reply, isAdmin, mentioned }
const routes = [];

// Command rahasia: tetap bisa dipanggil lewat prefix seperti biasa,
// tapi sengaja DIHILANGKAN dari .menu, .allmenu, dan menu kategori manapun.
const HIDDEN_COMMANDS = new Set([
    'ryoiken', 'ryoikitenkai', 'domainexpansion', 'tenkai',
]);

function reg(aliases, handler) {
    for (const a of aliases) routes.push([a, handler]);
}

// ── MENU / HELP ──────────────────────────────────────────────────────────
reg(['menu', 'help', 'start'], async (ctx) => sendMainMenu(ctx.reply, ctx.sender, ctx.sock, ctx.jid, ctx.msg, {
    isOwner: ctx.isOwner,
    isPremium: ctx.isPremium,
    pushName: ctx.msg?.pushName,
    botStartTime: BOT_START_TIME,
}));

// (Handler .allmenu didaftarkan di bawah, setelah routeMap tersedia —
//  lihat dekat definisi getAllCommandNames())
reg(['menurpg', 'rpgmenu', 'menugame'], async (ctx) => sendRpgMenu(ctx.reply));
reg(['menuadmin', 'adminmenu'], async (ctx) => sendAdminMenu(ctx.reply));
reg(['menufun', 'funmenu'], async (ctx) => sendFunMenu(ctx.reply));
reg(['menutools', 'toolsmenu'], async (ctx) => sendToolsMenu(ctx.reply));
reg(['menumedia', 'mediamenu'], async (ctx) => sendMediaMenu(ctx.reply));
reg(['menubot', 'botmenu'], async (ctx) => sendBotMenu(ctx.reply));

// .totalfitur — tampilkan jumlah total command/fitur yang terdaftar di
// bot ini. Pakai getRegisteredCommandCount() (didefinisikan di bawah,
// setelah routeMap dibuat) supaya angkanya selalu akurat & otomatis
// ikut bertambah kalau ada command baru — tidak di-hardcode manual.
reg(['totalfitur', 'totalfeature', 'jumlahfitur'], async (ctx) => {
    const total = getRegisteredCommandCount();
    const prefix = settings.prefix || '.';
    await ctx.reply(
`📦 *TOTAL FITUR ${settings.botName.toUpperCase()}*
━━━━━━━━━━━━━━━━━━
✨ Total command terdaftar : *${total} fitur*
━━━━━━━━━━━━━━━━━━
💡 Ketik *${prefix}allmenu* untuk lihat daftar lengkapnya.
💡 Ketik *${prefix}menu* untuk tampilan ringkas per kategori.`
    );
});

// ── REGISTRASI WAJIB (.daftar nama.umur) ──────────────────────────────────
reg(['daftar', 'register'], async (ctx) => {
    // Balasan .daftar yang MENYURUH/MEMANDU user daftar (belum terdaftar,
    // format salah, dsb) pakai thumbnail khusus (settings.thumbnailDaftar)
    // lewat replyWithImage. Khusus balasan "PENDAFTARAN BERHASIL" di bawah
    // SENGAJA pakai ctx.reply (teks polos) — thumbnail dihapus dari situ saja.
    const kirim = (text) => replyWithImage(ctx.sock, ctx.jid, ctx.msg, settings.thumbnailDaftar, text);

    if (isRegistered(ctx.sender) || ctx.isOwner) {
        const profile = getProfile(ctx.sender);
        if (profile) {
            return kirim(`✅ Kamu sudah terdaftar sebagai *${profile.name}* (${profile.age} tahun).`);
        }
        return kirim('✅ Kamu sudah bisa pakai bot ini (Owner/Creator otomatis terdaftar).');
    }

    const parsed = parseDaftarInput(ctx.args.join(' '));
    if (!parsed) {
        return kirim(
`📋 *CARA DAFTAR*
━━━━━━━━━━━━━━━━━━
◈ Format  : *${settings.prefix}daftar nama.umur*
◈ Contoh  : *${settings.prefix}daftar Gojo.20*
━━━━━━━━━━━━━━━━━━`
        );
    }

    const result = register(ctx.sender, parsed.name, parsed.age);
    if (!result.ok) return kirim(`❌ ${result.reason}`);

    await ctx.reply(
`✅ *PENDAFTARAN BERHASIL!*
━━━━━━━━━━━━━━━━━━
◈ Nama : *${parsed.name}*
◈ Umur : *${parsed.age} tahun*
━━━━━━━━━━━━━━━━━━
Selamat bergabung di *${settings.botName}*! 🌊
Ketik *${settings.prefix}menu* untuk lihat semua command.`
    );
});

// ── RPG: CHARACTER ───────────────────────────────────────────────────────
reg(['rpg', 'mulai', 'startrpg', 'createchar'], async (ctx) => rpgCommands.startRPG(ctx.reply, ctx.sender, ctx.args));
reg(['class', 'ganticlass', 'setclass'], async (ctx) => rpgCommands.setClass(ctx.reply, ctx.sender, ctx.args));
reg(['profil', 'profile', 'cek', 'stats', 'char'], async (ctx) => rpgCommands.showProfile(ctx.reply, ctx.sender, ctx.msg, ctx.mentioned));
reg(['inventory', 'inv', 'bag'], async (ctx) => rpgCommands.showInventory(ctx.reply, ctx.sender));
reg(['equip', 'pakai'], async (ctx) => rpgCommands.equipItem(ctx.reply, ctx.sender, ctx.args));
reg(['unequip', 'lepas'], async (ctx) => rpgCommands.unequipItem(ctx.reply, ctx.sender, ctx.args));
reg(['use', 'pakaiitem', 'minum'], async (ctx) => rpgCommands.useItem(ctx.reply, ctx.sender, ctx.args));
reg(['istirahat', 'rest', 'tidur'], async (ctx) => rpgCommands.rest(ctx.reply, ctx.sender));

// ── RPG: COMBAT ──────────────────────────────────────────────────────────
reg(['hunt', 'berburu', 'buru'], async (ctx) => rpgCommands.hunt(ctx.reply, ctx.sender));
reg(['lawan', 'battle', 'pvp', 'duel'], async (ctx) => rpgCommands.battle(ctx.reply, ctx.sender, ctx.mentioned));
reg(['bossinfo', 'listboss', 'daftarboss'], async (ctx) => rpgCommands2.bossInfo(ctx.reply));
reg(['boss', 'raid', 'lawanboss'], async (ctx) => rpgCommands2.fightBoss(ctx.reply, ctx.sender, ctx.args));
reg(['dungeoninfo', 'listdungeon', 'daftardungeon'], async (ctx) => rpgCommands2.dungeonInfo(ctx.reply));
reg(['dungeon', 'masukdungeon', 'explore'], async (ctx) => rpgCommands2.enterDungeon(ctx.reply, ctx.sender, ctx.args));

// ── RPG: ECONOMY ─────────────────────────────────────────────────────────
reg(['toko', 'shop', 'store'], async (ctx) => rpgCommands2.showShop(ctx.reply, ctx.args));
reg(['beli', 'buy', 'belanja'], async (ctx) => rpgCommands2.buyItem(ctx.reply, ctx.sender, ctx.args));
reg(['jual', 'sell'], async (ctx) => rpgCommands2.sellItem(ctx.reply, ctx.sender, ctx.args));
reg(['daily', 'klaim', 'absen'], async (ctx) => rpgCommands2.dailyReward(ctx.reply, ctx.sender));
reg(['joblist', 'listjob', 'daftarkerja'], async (ctx) => rpgCommands2.joblist(ctx.reply));
reg(['kerja', 'work', 'job'], async (ctx) => rpgCommands2.work(ctx.reply, ctx.sender, ctx.args));
reg(['nabung', 'deposit', 'save', 'tabung'], async (ctx) => rpgCommands2.bankDeposit(ctx.reply, ctx.sender, ctx.args));
reg(['tarik', 'withdraw', 'ambil'], async (ctx) => rpgCommands2.bankWithdraw(ctx.reply, ctx.sender, ctx.args));
reg(['transfer', 'kirim', 'kirimgold', 'send'], async (ctx) => rpgCommands2.transfer(ctx.reply, ctx.sender, ctx.mentioned, ctx.args));
reg(['rob', 'rampok', 'curi'], async (ctx) => rpgCommands2.rob(ctx.reply, ctx.sender, ctx.mentioned));

// ── RPG: PETS ─────────────────────────────────────────────────────────────
reg(['petshop', 'tokopet'], async (ctx) => rpgCommands2.petShop(ctx.reply));
reg(['buypet', 'belipet', 'adopsi'], async (ctx) => rpgCommands2.buyPet(ctx.reply, ctx.sender, ctx.args));
reg(['petinfo', 'mypet', 'petku'], async (ctx) => rpgCommands2.petInfo(ctx.reply, ctx.sender));
reg(['setpet', 'gantipet', 'pilihpet'], async (ctx) => rpgCommands2.setPet(ctx.reply, ctx.sender, ctx.args));

// ── RPG: QUEST / ACHIEVEMENT ─────────────────────────────────────────────
reg(['quest', 'misi', 'questlist'], async (ctx) => rpgCommands2.showQuests(ctx.reply, ctx.sender));
reg(['questclaim', 'klaimquest', 'klaimmisi'], async (ctx) => rpgCommands2.claimQuest(ctx.reply, ctx.sender, ctx.args));
reg(['achievement', 'pencapaian', 'lencana'], async (ctx) => rpgCommands2.showAchievements(ctx.reply, ctx.sender));

// ── RPG: SOCIAL / RANKING ────────────────────────────────────────────────
reg(['ranking', 'top', 'top10'], async (ctx) => rpgCommands2.showRanking(ctx.reply));
reg(['leaderboard', 'papantop', 'lb'], async (ctx) => rpgCommands2.leaderboard(ctx.reply, ctx.args));
reg(['marry', 'nikah', 'menikah'], async (ctx) => rpgCommands2.marry(ctx.reply, ctx.sender, ctx.mentioned));
reg(['divorce', 'cerai', 'pisah'], async (ctx) => rpgCommands2.divorce(ctx.reply, ctx.sender));

// ── ADMIN: MUTE ──────────────────────────────────────────────────────────
reg(['mute', 'bisukan'], async (ctx) => adminCommands.muteGroup(ctx.sock, ctx.reply, ctx.jid, ctx.args, ctx.isAdmin));
reg(['unmute', 'bukabisu'], async (ctx) => adminCommands.unmuteGroup(ctx.reply, ctx.jid, ctx.isAdmin));
reg(['mutestatus', 'cekmute'], async (ctx) => adminCommands.muteStatus(ctx.reply, ctx.jid));

// ── ADMIN: MEMBER MANAGEMENT ─────────────────────────────────────────────
reg(['kick', 'keluarkan', 'tendang'], async (ctx) => adminCommands.kickMember(ctx.sock, ctx.reply, ctx.msg, ctx.jid, ctx.mentioned, ctx.isAdmin));
reg(['ryoiken', 'ryoikitenkai', 'domainexpansion', 'tenkai'], async (ctx) => adminCommands.ryoikiTenkaiKick(ctx.sock, ctx.reply, ctx.msg, ctx.jid, ctx.mentioned, ctx.isAdmin));
reg(['promote', 'jadikanadmin', 'naikkan'], async (ctx) => adminCommands.promoteMember(ctx.sock, ctx.reply, ctx.msg, ctx.jid, ctx.mentioned, ctx.isAdmin));
reg(['demote', 'turunkan', 'copotadmin'], async (ctx) => adminCommands.demoteMember(ctx.sock, ctx.reply, ctx.msg, ctx.jid, ctx.mentioned, ctx.isAdmin));
reg(['add', 'tambahmember', 'invite'], async (ctx) => adminCommands.addMember(ctx.sock, ctx.reply, ctx.jid, ctx.args, ctx.isAdmin));

// ── ADMIN: WARN ───────────────────────────────────────────────────────────
reg(['warn', 'peringatan', 'beriwarn'], async (ctx) => adminCommands.warnMember(ctx.sock, ctx.reply, ctx.msg, ctx.jid, ctx.mentioned, ctx.isAdmin));
reg(['unwarn', 'hapuswarn'], async (ctx) => adminCommands.unwarnMember(ctx.sock, ctx.reply, ctx.msg, ctx.jid, ctx.mentioned, ctx.isAdmin));
reg(['checkwarn', 'cekwarn', 'totalwarn'], async (ctx) => adminCommands.checkWarn(ctx.reply, ctx.jid, ctx.mentioned, ctx.sender));
reg(['warnlimit', 'limitwarn', 'setwarnlimit'], async (ctx) => adminCommands.setWarnLimit(ctx.reply, ctx.jid, ctx.args, ctx.isAdmin));

// ── ADMIN: GROUP INFO / SETTINGS ─────────────────────────────────────────
reg(['groupinfo', 'infogrup', 'infogroup'], async (ctx) => adminCommands.groupInfo(ctx.sock, ctx.reply, ctx.jid));
reg(['setname', 'gantinamagrup', 'namagrup'], async (ctx) => adminCommands.setGroupName(ctx.sock, ctx.reply, ctx.jid, ctx.args, ctx.isAdmin));
reg(['setdesc', 'gantidesk', 'deskripsigrup'], async (ctx) => adminCommands.setGroupDesc(ctx.sock, ctx.reply, ctx.jid, ctx.args, ctx.isAdmin));
reg(['lockgroup', 'kuncigrup', 'closegroup'], async (ctx) => adminCommands.lockGroup(ctx.sock, ctx.reply, ctx.jid, ctx.isAdmin));
reg(['unlockgroup', 'bukagrup', 'opengroup'], async (ctx) => adminCommands.unlockGroup(ctx.sock, ctx.reply, ctx.jid, ctx.isAdmin));
reg(['link', 'linkgrup', 'invitelink', 'getlink'], async (ctx) => adminCommands.getInviteLink(ctx.sock, ctx.reply, ctx.jid, ctx.isAdmin));
reg(['revoke', 'resetlink', 'revokelink'], async (ctx) => adminCommands.revokeInviteLink(ctx.sock, ctx.reply, ctx.jid, ctx.isAdmin));
reg(['leave', 'keluargrup', 'botkeluar'], async (ctx) => adminCommands.leaveGroup(ctx.sock, ctx.reply, ctx.jid, ctx.isAdmin));
reg(['hidetag', 'htag', 'tagsemua'], async (ctx) => adminCommands.hidetag(ctx.sock, ctx.reply, ctx.msg, ctx.jid, ctx.args, ctx.isAdmin));
reg(['tagall', 'mentionall', 'tagsemuamember'], async (ctx) => adminCommands.tagAll(ctx.sock, ctx.reply, ctx.msg, ctx.jid, ctx.args, ctx.isAdmin));
reg(['listadmin', 'daftaradmin', 'admins'], async (ctx) => adminCommands.listAdmins(ctx.sock, ctx.reply, ctx.jid));
reg(['membercount', 'jumlahmember', 'totalmember'], async (ctx) => adminCommands.groupMembersCount(ctx.sock, ctx.reply, ctx.jid));

// ── ADMIN: WELCOME / FAREWELL ────────────────────────────────────────────
reg(['setwelcome', 'aturwelcome'], async (ctx) => adminCommands.setWelcomeMsg(ctx.reply, ctx.jid, ctx.args, ctx.isAdmin));
reg(['setfarewell', 'aturfarewell', 'aturperpisahan'], async (ctx) => adminCommands.setFarewellMsg(ctx.reply, ctx.jid, ctx.args, ctx.isAdmin));
reg(['welcome'], async (ctx) => adminCommands.toggleSetting(ctx.reply, ctx.jid, 'welcome', 'Welcome Message', ctx.args, ctx.isAdmin));
reg(['farewell'], async (ctx) => adminCommands.toggleSetting(ctx.reply, ctx.jid, 'farewell', 'Farewell Message', ctx.args, ctx.isAdmin));

// ── ADMIN: PROTECTION TOGGLES ────────────────────────────────────────────
reg(['antigb'], async (ctx) => adminCommands.toggleSetting(ctx.reply, ctx.jid, 'antigb', 'Anti-GB', ctx.args, ctx.isAdmin));
reg(['antilink'], async (ctx) => adminCommands.toggleSetting(ctx.reply, ctx.jid, 'antilink', 'Anti-Link', ctx.args, ctx.isAdmin));
reg(['antispam'], async (ctx) => adminCommands.toggleSetting(ctx.reply, ctx.jid, 'antispam', 'Anti-Spam', ctx.args, ctx.isAdmin));
reg(['antitoxic'], async (ctx) => adminCommands.toggleSetting(ctx.reply, ctx.jid, 'antitoxic', 'Anti-Toxic', ctx.args, ctx.isAdmin));
reg(['antishortlink', 'antishorturl'], async (ctx) => adminCommands.toggleSetting(ctx.reply, ctx.jid, 'antishortlink', 'Anti-ShortLink', ctx.args, ctx.isAdmin));
reg(['slowmode', 'modelambat'], async (ctx) => adminCommands.setSlowmode(ctx.reply, ctx.jid, ctx.args, ctx.isAdmin));
reg(['lockmedia'], async (ctx) => adminCommands.lockType(ctx.reply, ctx.jid, 'media', ctx.args, ctx.isAdmin));
reg(['lockstiker', 'locksticker'], async (ctx) => adminCommands.lockType(ctx.reply, ctx.jid, 'sticker', ctx.args, ctx.isAdmin));

// ── ADMIN: PROTEKSI TAMBAHAN (v3.1.0) ────────────────────────────────────
reg(['antilinkphising', 'antiphising', 'antiphishing'], async (ctx) => adminCommands.toggleSetting(ctx.reply, ctx.jid, 'antilinkphising', 'Anti-Link-Phising', ctx.args, ctx.isAdmin));
reg(['antijudol', 'antijudi'], async (ctx) => adminCommands.toggleSetting(ctx.reply, ctx.jid, 'antijudol', 'Anti-Judol', ctx.args, ctx.isAdmin));
reg(['antipinjol', 'antipinjaman'], async (ctx) => adminCommands.toggleSetting(ctx.reply, ctx.jid, 'antipinjol', 'Anti-Pinjol', ctx.args, ctx.isAdmin));
reg(['anticaps', 'antikapital'], async (ctx) => adminCommands.toggleSetting(ctx.reply, ctx.jid, 'anticaps', 'Anti-Caps', ctx.args, ctx.isAdmin));
reg(['antivirtex', 'antivirustext'], async (ctx) => adminCommands.toggleSetting(ctx.reply, ctx.jid, 'antivirtex', 'Anti-Virtex', ctx.args, ctx.isAdmin));
reg(['antitag', 'antitagsw'], async (ctx) => adminCommands.toggleSetting(ctx.reply, ctx.jid, 'antitag', 'Anti-Tag', ctx.args, ctx.isAdmin));
reg(['antiflood'], async (ctx) => adminCommands.toggleSetting(ctx.reply, ctx.jid, 'antispam', 'Anti-Spam/Anti-Flood', ctx.args, ctx.isAdmin));
reg(['resetprotection', 'matikansemuaproteksi', 'unprotectall'], async (ctx) => adminCommands4.resetProtectionAll(ctx.reply, ctx.jid, ctx.isAdmin));
reg(['antilinkall', 'fullantilink'], async (ctx) => adminCommands4.setAntiLinkAll(ctx.reply, ctx.jid, ctx.args, ctx.isAdmin));
reg(['helpproteksi', 'panduanproteksi'], async (ctx) => adminCommands4.helpProteksi(ctx.reply));
reg(['grouplockstatus', 'statusproteksi', 'ceksemuaproteksi'], async (ctx) => adminCommands4.groupLockStatus(ctx.reply, ctx.jid));

// ── ADMIN: CUSTOM BAD-WORD (perluasan Anti-Toxic per-grup) ──────────────
reg(['addbadword', 'tambahkatakasar'], async (ctx) => adminCommands4.addBadWordCmd(ctx.reply, ctx.jid, ctx.args, ctx.isAdmin));
reg(['delbadword', 'hapuskatakasar'], async (ctx) => adminCommands4.delBadWordCmd(ctx.reply, ctx.jid, ctx.args, ctx.isAdmin));
reg(['listbadword', 'daftarkatakasar'], async (ctx) => adminCommands4.listBadWordCmd(ctx.reply, ctx.jid, ctx.isAdmin));

// ── ADMIN: LINK ALLOWLIST (pengecualian Anti-Link) ───────────────────────
reg(['allowlinkadd', 'izinkanlink'], async (ctx) => adminCommands4.allowLinkAdd(ctx.reply, ctx.jid, ctx.args, ctx.isAdmin));
reg(['allowlinkdel', 'hapusizinlink'], async (ctx) => adminCommands4.allowLinkDel(ctx.reply, ctx.jid, ctx.args, ctx.isAdmin));
reg(['allowlinklist', 'daftarizinlink'], async (ctx) => adminCommands4.allowLinkShow(ctx.reply, ctx.jid, ctx.isAdmin));

// ── ADMIN: WHITELIST PROTEKSI ────────────────────────────────────────────
reg(['whitelistadd', 'putihkan'], async (ctx) => adminCommands4.whitelistAdd(ctx.reply, ctx.jid, ctx.mentioned, ctx.isAdmin));
reg(['whitelistdel', 'hapusputih'], async (ctx) => adminCommands4.whitelistDel(ctx.reply, ctx.jid, ctx.mentioned, ctx.isAdmin));
reg(['whitelist', 'daftarputih'], async (ctx) => adminCommands4.whitelistShow(ctx.reply, ctx.jid, ctx.isAdmin));

// ── ADMIN: LOCK TIPE KONTEN GRANULAR (v3.1.0) ────────────────────────────
reg(['lockimage', 'lockgambar'], async (ctx) => adminCommands.lockType(ctx.reply, ctx.jid, 'image', ctx.args, ctx.isAdmin));
reg(['lockvideo', 'lockvidio'], async (ctx) => adminCommands.lockType(ctx.reply, ctx.jid, 'video', ctx.args, ctx.isAdmin));
reg(['lockdocument', 'lockdokumen'], async (ctx) => adminCommands.lockType(ctx.reply, ctx.jid, 'document', ctx.args, ctx.isAdmin));
reg(['lockcontact', 'lockkontak'], async (ctx) => adminCommands.lockType(ctx.reply, ctx.jid, 'contact', ctx.args, ctx.isAdmin));
reg(['locklocation', 'locklokasi'], async (ctx) => adminCommands.lockType(ctx.reply, ctx.jid, 'location', ctx.args, ctx.isAdmin));
reg(['lockvn', 'lockvoicenote'], async (ctx) => adminCommands.lockType(ctx.reply, ctx.jid, 'voice', ctx.args, ctx.isAdmin));
reg(['lockaudio', 'lockmusik'], async (ctx) => adminCommands.lockType(ctx.reply, ctx.jid, 'audio', ctx.args, ctx.isAdmin));
reg(['lockgif', 'lockgifplay'], async (ctx) => adminCommands.lockType(ctx.reply, ctx.jid, 'gif', ctx.args, ctx.isAdmin));
reg(['lockpoll', 'lockjajak'], async (ctx) => adminCommands.lockType(ctx.reply, ctx.jid, 'poll', ctx.args, ctx.isAdmin));

// ── ADMIN: MUTE PER-MEMBER (beda dari .mute grup-wide) ───────────────────
reg(['mutemember', 'bisukanmember'], async (ctx) => adminCommands4.muteMemberCmd(ctx.reply, ctx.jid, ctx.mentioned, ctx.isAdmin));
reg(['unmutemember', 'bukabisumember'], async (ctx) => adminCommands4.unmuteMemberCmd(ctx.reply, ctx.jid, ctx.mentioned, ctx.isAdmin));
reg(['listmutedmember', 'daftarbisu'], async (ctx) => adminCommands4.listMutedMemberCmd(ctx.reply, ctx.jid, ctx.isAdmin));

// ── ADMIN: MEMBER MANAGEMENT LANJUTAN ────────────────────────────────────
reg(['kickall', 'kicksemua', 'tendangsemua'], async (ctx) => adminCommands4.kickAll(ctx.sock, ctx.reply, ctx.msg, ctx.jid, ctx.isAdmin, ctx.args));
reg(['warnall', 'warnsemua', 'peringatkansemua'], async (ctx) => adminCommands4.warnAll(ctx.sock, ctx.reply, ctx.msg, ctx.jid, ctx.isAdmin));
reg(['cekwarnall', 'listwarn', 'semuawarn'], async (ctx) => adminCommands4.listWarnAll(ctx.reply, ctx.jid));
reg(['topwarn', 'warnterbanyak'], async (ctx) => adminCommands4.topWarn(ctx.reply, ctx.jid));
reg(['resetwarnall', 'hapussemuawarn'], async (ctx) => adminCommands4.resetWarnAllCmd(ctx.reply, ctx.jid, ctx.isAdmin));
reg(['banlist', 'daftarblokir'], async (ctx) => adminCommands2.listBanned(ctx.reply, ctx.jid));
reg(['unbanall', 'hapussemuablokir'], async (ctx) => adminCommands2.unbanAll(ctx.reply, ctx.jid, ctx.isAdmin));
reg(['slowmodeoff', 'matikanslow'], async (ctx) => adminCommands.setSlowmode(ctx.reply, ctx.jid, ['0'], ctx.isAdmin));

// ── ADMIN: INFO / DASHBOARD GRUP ──────────────────────────────────────────
reg(['cekbot', 'botadmin', 'statusbot'], async (ctx) => adminCommands4.checkBotAdmin(ctx.sock, ctx.reply, ctx.jid));
reg(['groupsummary', 'dashboardgrup', 'ringkasangrup'], async (ctx) => adminCommands4.groupSummary(ctx.sock, ctx.reply, ctx.jid));
reg(['groupage', 'umurgrup'], async (ctx) => adminCommands4.groupAge(ctx.sock, ctx.reply, ctx.jid));
reg(['admincount', 'jumlahadmin'], async (ctx) => adminCommands4.adminCount(ctx.sock, ctx.reply, ctx.jid));
reg(['groupcreator', 'pembuatgrup'], async (ctx) => adminCommands4.groupCreatorInfo(ctx.sock, ctx.reply, ctx.jid));
reg(['exportmember', 'datamember', 'listmemberdata'], async (ctx) => adminCommands4.exportMember(ctx.sock, ctx.reply, ctx.jid));

// ── ADMIN: BACKUP / RESTORE PENGATURAN GRUP ──────────────────────────────
reg(['backupsetting', 'backupgrup'], async (ctx) => adminCommands4.backupSetting(ctx.reply, ctx.jid, ctx.isAdmin));
reg(['restoresetting', 'restoregrup'], async (ctx) => adminCommands4.restoreSetting(ctx.reply, ctx.jid, ctx.isAdmin));

// ── ADMIN: APPROVAL JOIN REQUEST ──────────────────────────────────────────
reg(['listrequest', 'pendingrequest', 'daftarrequest'], async (ctx) => adminCommands4.listJoinRequests(ctx.sock, ctx.reply, ctx.jid, ctx.isAdmin));
reg(['approverequest', 'terimarequest'], async (ctx) => adminCommands4.approveJoinRequest(ctx.sock, ctx.reply, ctx.jid, ctx.args, ctx.mentioned, ctx.isAdmin));
reg(['rejectrequest', 'tolakrequest'], async (ctx) => adminCommands4.rejectJoinRequest(ctx.sock, ctx.reply, ctx.jid, ctx.args, ctx.mentioned, ctx.isAdmin));
reg(['approveall', 'terimasemua'], async (ctx) => adminCommands4.approveAllRequests(ctx.sock, ctx.reply, ctx.jid, ctx.isAdmin));
reg(['rejectall', 'tolaksemua'], async (ctx) => adminCommands4.rejectAllRequests(ctx.sock, ctx.reply, ctx.jid, ctx.isAdmin));

// ── ADMIN: JADWAL BUKA/TUTUP GRUP OTOMATIS ────────────────────────────────
reg(['jadwalbuka', 'autobuka'], async (ctx) => adminCommands4.setOpenSchedule(ctx.reply, ctx.jid, ctx.args, ctx.isAdmin));
reg(['jadwaltutup', 'autotutup'], async (ctx) => adminCommands4.setCloseSchedule(ctx.reply, ctx.jid, ctx.args, ctx.isAdmin));
reg(['canceljadwalgrup', 'batalotomatis'], async (ctx) => adminCommands4.cancelSchedule(ctx.reply, ctx.jid, ctx.isAdmin));
reg(['cekjadwalgrup', 'statusotomatis'], async (ctx) => adminCommands4.checkScheduleStatus(ctx.reply, ctx.jid));

// ── ADMIN: KONFIGURASI GRUP NATIVE WHATSAPP LAINNYA ──────────────────────
reg(['seticon', 'gantiicon', 'ubahicon'], async (ctx) => adminCommands4.setGroupIcon(ctx.sock, ctx.reply, ctx.msg, ctx.jid, ctx.isAdmin));
reg(['hapusicon', 'removeicon'], async (ctx) => adminCommands4.removeGroupIcon(ctx.sock, ctx.reply, ctx.jid, ctx.isAdmin));
reg(['lockinfo', 'kuncinfogrup'], async (ctx) => adminCommands4.lockGroupInfo(ctx.sock, ctx.reply, ctx.jid, ctx.isAdmin));
reg(['unlockinfo', 'bukainfogrup'], async (ctx) => adminCommands4.unlockGroupInfo(ctx.sock, ctx.reply, ctx.jid, ctx.isAdmin));
reg(['ephemeral', 'pesansementara'], async (ctx) => adminCommands4.setEphemeral(ctx.sock, ctx.reply, ctx.jid, ctx.args, ctx.isAdmin));

// ── FUN / GAMES ───────────────────────────────────────────────────────────
reg(['quote', 'katabijak', 'motivasi'], async (ctx) => funCommands.quote(ctx.reply));
reg(['fact', 'fakta', 'faktaunik'], async (ctx) => funCommands.fact(ctx.reply));
reg(['riddle', 'tekateki'], async (ctx) => funCommands.riddle(ctx.reply, ctx.jid));
reg(['jawab', 'answer'], async (ctx) => {
    await funCommands.answerRiddle(ctx.reply, ctx.jid, ctx.args);
    await funCommands.answerTebak(async () => {}, ctx.jid, ctx.args).catch(() => {});
});
reg(['truth'], async (ctx) => funCommands.truth(ctx.reply));
reg(['dare'], async (ctx) => funCommands.dare(ctx.reply));
reg(['tebakgambar', 'guessimage'], async (ctx) => funCommands.tebakGambar(ctx.reply, ctx.jid));
reg(['pantun'], async (ctx) => funCommands.pantun(ctx.reply));
reg(['zodiak', 'horoscope', 'ramalan'], async (ctx) => funCommands.horoscope(ctx.reply, ctx.args));
reg(['coinflip', 'lempar koin', 'koin'], async (ctx) => funCommands.coinFlip(ctx.reply));
reg(['dice', 'dadu', 'roll'], async (ctx) => funCommands.rollDice(ctx.reply, ctx.args));
reg(['rps', 'bgk', 'batugunting'], async (ctx) => funCommands.rps(ctx.reply, ctx.args));
reg(['slot', 'judi', 'slotmachine'], async (ctx) => funCommands.slot(ctx.reply, ctx.sender));
reg(['tebakangka', 'guessnumber'], async (ctx) => funCommands.tebakAngka(ctx.reply, ctx.jid));
reg(['tebak'], async (ctx) => funCommands.guessNumber(ctx.reply, ctx.jid, ctx.args));
reg(['wyr', 'wouldyourather', 'pilihmana'], async (ctx) => funCommands.wouldYouRather(ctx.reply));
reg(['jodoh', 'ceklodoh', 'lovetest'], async (ctx) => funCommands.checkJodoh(ctx.reply, ctx.sender, ctx.mentioned));
reg(['tarot', 'kartutarot'], async (ctx) => funCommands.tarotCard(ctx.reply));
reg(['fortunecookie', 'ramalankue'], async (ctx) => funCommands.fortuneCookie(ctx.reply));
reg(['lovecalc', 'hitungcinta', 'kalkulatorcinta'], async (ctx) => funCommands.hitungCinta(ctx.reply, ctx.sender, ctx.mentioned, ctx.args));

// ── FUN: GOJO SATORU SPECIAL ──────────────────────────────────────────────
reg(['gojo', 'gojoquote', 'katagojo'], async (ctx) => gojoCommands.gojoQuote(ctx.reply));
reg(['gojoteknik', 'jurusgojo', 'tekniksihir'], async (ctx) => gojoCommands.gojoTeknik(ctx.reply));
reg(['gojoroast', 'roastgojo'], async (ctx) => gojoCommands.gojoRoast(ctx.reply, ctx.sender, ctx.mentioned));
reg(['gojohype', 'semangatgojo', 'gojosupport'], async (ctx) => gojoCommands.gojoHype(ctx.reply, ctx.sender, ctx.mentioned));
reg(['gojofact', 'faktagojo'], async (ctx) => gojoCommands.gojoFact(ctx.reply));
reg(['gojopower', 'ceklevelgojo', 'powerlevel'], async (ctx) => gojoCommands.gojoPower(ctx.reply, ctx.sender, ctx.mentioned));

// ── TOOLS: TEXT ───────────────────────────────────────────────────────────
reg(['upper', 'kapital'], async (ctx) => textTools.upper(ctx.reply, ctx.args));
reg(['lower', 'kecil'], async (ctx) => textTools.lower(ctx.reply, ctx.args));
reg(['reverse', 'balik'], async (ctx) => textTools.reverse(ctx.reply, ctx.args));
reg(['tobinary', 'kebinary'], async (ctx) => textTools.toBinary(ctx.reply, ctx.args));
reg(['frombinary', 'daribinary'], async (ctx) => textTools.fromBinary(ctx.reply, ctx.args));
reg(['tobase64', 'kebase64'], async (ctx) => textTools.toBase64(ctx.reply, ctx.args));
reg(['frombase64', 'daribase64'], async (ctx) => textTools.fromBase64(ctx.reply, ctx.args));
reg(['tohex', 'kehex'], async (ctx) => textTools.toHex(ctx.reply, ctx.args));
reg(['fromhex', 'darihex'], async (ctx) => textTools.fromHex(ctx.reply, ctx.args));
reg(['rot13'], async (ctx) => textTools.rot13(ctx.reply, ctx.args));
reg(['leet', 'leetspeak'], async (ctx) => textTools.leet(ctx.reply, ctx.args));
reg(['alternating', 'acakcase'], async (ctx) => textTools.alternating(ctx.reply, ctx.args));
reg(['wordcount', 'hitungkata'], async (ctx) => textTools.countWords(ctx.reply, ctx.args));

// ── TOOLS: MATH ───────────────────────────────────────────────────────────
reg(['calc', 'hitung', 'kalkulator'], async (ctx) => mathTools.calc(ctx.reply, ctx.args));
reg(['persen', 'percent'], async (ctx) => mathTools.percent(ctx.reply, ctx.args));
reg(['bmi', 'imt'], async (ctx) => mathTools.bmi(ctx.reply, ctx.args));
reg(['kurs', 'currency'], async (ctx) => mathTools.convertCurrencyNote(ctx.reply));
reg(['umur', 'age', 'hitungumur'], async (ctx) => mathTools.ageCalc(ctx.reply, ctx.args));

// ── TOOLS: CONVERTER ──────────────────────────────────────────────────────
reg(['convertlength', 'konversipanjang'], async (ctx) => converterTools.convertLength(ctx.reply, ctx.args));
reg(['convertweight', 'konversiberat'], async (ctx) => converterTools.convertWeight(ctx.reply, ctx.args));
reg(['convertsuhu', 'convertemp'], async (ctx) => converterTools.convertTemp(ctx.reply, ctx.args));

// ── TOOLS: GENERATOR ──────────────────────────────────────────────────────
reg(['genpassword', 'buatpassword', 'password'], async (ctx) => generatorTools.genPassword(ctx.reply, ctx.args));
reg(['genuuid', 'uuid'], async (ctx) => generatorTools.genUUID(ctx.reply));
reg(['pilih', 'choose', 'pickrandom'], async (ctx) => generatorTools.pickRandom(ctx.reply, ctx.args));
reg(['shuffle', 'acak'], async (ctx) => generatorTools.shuffleList(ctx.reply, ctx.args));

// ── TOOLS: INFO ───────────────────────────────────────────────────────────
reg(['ping'], async (ctx) => {
    const start = Date.now();
    await ctx.sock.sendPresenceUpdate('composing', ctx.jid);
    const latency = Date.now() - start;
    await ctx.reply(
`🏓 *PONG!*

◈ *Latensi*  : \`${latency}ms\`
◈ *Status*   : 🟢 Online & Aktif
◈ *Runtime*  : ${fmtDuration(Date.now() - BOT_START_TIME)}
◈ *Users*    : ${countUsers()} player terdaftar
◈ *Grup*     : ${countGroups()} grup aktif
◈ *Cmd Total*: ${getTotalCommandsRan()} kali dijalankan`
    );
});

reg(['owner', 'creator', 'dev', 'developer'], async (ctx) => {
    const creator = getCreatorInfo();
    const owners = listOwners();
    const mainOwnerNum = settings.ownerNumber ? settings.ownerNumber.replace(/[^0-9]/g, '') : null;
    const extraOwners = owners.filter(o => o.number !== mainOwnerNum);
    const ownerLines = extraOwners.length
        ? extraOwners.map((o, i) => `${i + 1}. +${o.number}`).join('\n')
        : '_(belum ada Owner tambahan — pakai .addowner atau edit `ownerNumbers` di setting.js)_';
    await ctx.reply(
`👑 *INFO CREATOR & OWNER*

◈ *Creator* : ${creator.name}
◈ *Nomor*   : +${creator.number}
_(Creator tidak bisa diganti lewat command apapun)_

⭐ *${settings.ownerName || 'Owner'}*${mainOwnerNum ? `\n◈ *Nomor* : +${mainOwnerNum}` : '\n_(belum diisi — set `ownerName` & `ownerNumber` di setting.js)_'}

📋 *Owner Lainnya:*
${ownerLines}
_(Nama & nomor Owner utama bisa diganti lewat setting.js: \`ownerName\` dan \`ownerNumber\`)_

◈ *Bot* : ${settings.botName} v${settings.botVersion || '3.0.0'}

📞 Hubungi Creator jika ada pertanyaan,\nlaporan bug, atau request fitur!

_wa.me/${creator.number}_`
    );
});

// .pembayaran — info nomor e-wallet Owner (DANA/GoPay/OVO). Nomornya
// diambil dari setting.js (nodana/nogopay/noovo) supaya Owner bisa ganti
// sendiri kapan saja tanpa perlu edit command ini.
reg(['pembayaran', 'payment', 'bayar'], async (ctx) => {
    await ctx.reply(
`💰 *INFO PEMBAYARAN*

◈ DANA  : ${settings.nodana  || '_(belum diisi)_'}
◈ GoPay : ${settings.nogopay || '_(belum diisi)_'}
◈ OVO   : ${settings.noovo   || '_(belum diisi)_'}

Silakan transfer ke salah satu nomor di atas sesuai nominal yang disepakati, lalu kirim bukti transfer ke Owner untuk konfirmasi.

_(Nomor bisa diganti Owner lewat setting.js: \`nodana\`, \`nogopay\`, \`noovo\`)_`
    );
});

// .sosmedowner — info sosial media Owner, diambil dari setting.js
// (ig/tele/yt) supaya bisa diganti Owner kapan saja.
reg(['sosmedowner', 'sosmed', 'socialmedia'], async (ctx) => {
    await ctx.reply(
`📱 *SOSIAL MEDIA OWNER*

◈ Instagram : ${settings.ig   || '_(belum diisi)_'}
◈ Telegram  : ${settings.tele || '_(belum diisi)_'}
◈ YouTube   : ${settings.yt   || '_(belum diisi)_'}

Yuk follow & subscribe buat dukung Owner! 🙌

_(Bisa diganti Owner lewat setting.js: \`ig\`, \`tele\`, \`yt\`)_`
    );
});

// ── JABATAN: CREATOR / OWNER / PREMIUM ────────────────────────────────────
// Owner & Premium sekarang GABUNGAN dari beberapa sumber:
//   1) `ownerNumber` (Owner utama, tunggal) + `ownerNumbers` (Owner
//      tambahan, array) / `premiumNumbers` di setting.js — manual edit
//      file, butuh restart bot supaya berlaku.
//   2) data/owners.json & data/premium.json (diatur lewat command
//      .addowner/.addprem saat bot berjalan, langsung aktif tanpa restart).
// .addowner boleh dipakai oleh Owner ATAUPUN Creator. .delowner & .delprem
// tetap lebih terbatas (lihat masing-masing handler di bawah).
// Nomor yang berasal dari setting.js TIDAK BISA dihapus lewat command
// (harus edit file itu langsung) — ini supaya nomor yang sudah di-set
// manual lewat file tidak bisa dicabut diam-diam lewat chat oleh siapapun.
reg(['listowner', 'daftarowner', 'cekowner'], async (ctx) => {
    const creator = getCreatorInfo();
    const owners = listOwners();
    const lines = [`👑 *Creator*: ${creator.name} (+${creator.number})`];
    if (owners.length === 0) {
        lines.push('', '⭐ *Owner*: _(belum ada Owner tambahan)_');
    } else {
        lines.push('', '⭐ *Daftar Owner:*');
        owners.forEach((o, i) => lines.push(`${i + 1}. +${o.number} _(${o.source})_`));
    }
    lines.push('', `_${settings.prefix}addowner @tag — tambah Owner (Owner/Creator)_`);
    await ctx.reply(lines.join('\n'));
});
reg(['addowner'], async (ctx) => {
    if (!ctx.isOwner) return ctx.reply('❌ Hanya *Owner* atau *Creator* yang bisa menambah Owner.');
    const target = ctx.mentioned?.[0] || (ctx.args?.[0] ? `${ctx.args[0].replace(/[^0-9]/g, '')}@s.whatsapp.net` : null);
    if (!target) return ctx.reply(`📌 Cara pakai: *${settings.prefix}addowner @tag* atau *${settings.prefix}addowner 628xxx*`);
    const result = addOwner(target);
    if (!result.ok) return ctx.reply(`❌ ${result.reason}`);
    await ctx.reply(`✅ @${target.split('@')[0]} berhasil dijadikan *Owner*.`);
});
reg(['delowner', 'removeowner'], async (ctx) => {
    if (!ctx.isCreator) return ctx.reply('❌ Hanya *Creator* yang bisa menghapus Owner.');
    const target = ctx.mentioned?.[0] || (ctx.args?.[0] ? `${ctx.args[0].replace(/[^0-9]/g, '')}@s.whatsapp.net` : null);
    if (!target) return ctx.reply(`📌 Cara pakai: *${settings.prefix}delowner @tag* atau *${settings.prefix}delowner 628xxx*`);
    const result = removeOwner(target);
    if (!result.ok) return ctx.reply(`❌ ${result.reason}`);
    await ctx.reply(`✅ @${target.split('@')[0]} sudah dicabut dari jabatan *Owner*.`);
});
reg(['listprem', 'listpremium', 'daftarpremium'], async (ctx) => {
    const premiums = listPremium();
    const lines = [];
    if (premiums.length === 0) {
        lines.push('💎 *Daftar Premium*', '', '_(belum ada user Premium)_');
    } else {
        lines.push(`💎 *Daftar Premium* (${premiums.length})`, '');
        premiums.forEach((p, i) => lines.push(`${i + 1}. +${p.number} _(${p.source})_`));
    }
    lines.push('', `_${settings.prefix}addprem @tag — tambah Premium (Owner only)_`);
    await ctx.reply(lines.join('\n'));
});
reg(['addprem', 'addpremium'], async (ctx) => {
    if (!ctx.isOwner) return ctx.reply('❌ Hanya *Owner* atau *Creator* yang bisa menambah Premium.');
    const target = ctx.mentioned?.[0] || (ctx.args?.[0] ? `${ctx.args[0].replace(/[^0-9]/g, '')}@s.whatsapp.net` : null);
    if (!target) return ctx.reply(`📌 Cara pakai: *${settings.prefix}addprem @tag* atau *${settings.prefix}addprem 628xxx*`);
    const result = addPremium(target);
    if (!result.ok) return ctx.reply(`❌ ${result.reason}`);
    await ctx.reply(`✅ @${target.split('@')[0]} berhasil dijadikan *Premium*. 💎`);
});
reg(['delprem', 'delpremium', 'removepremium'], async (ctx) => {
    if (!ctx.isOwner) return ctx.reply('❌ Hanya *Owner* atau *Creator* yang bisa menghapus Premium.');
    const target = ctx.mentioned?.[0] || (ctx.args?.[0] ? `${ctx.args[0].replace(/[^0-9]/g, '')}@s.whatsapp.net` : null);
    if (!target) return ctx.reply(`📌 Cara pakai: *${settings.prefix}delprem @tag* atau *${settings.prefix}delprem 628xxx*`);
    const result = removePremium(target);
    if (!result.ok) return ctx.reply(`❌ ${result.reason}`);
    await ctx.reply(`✅ Status *Premium* @${target.split('@')[0]} sudah dicabut.`);
});
reg(['cekjabatan', 'myrole', 'rolesaya', 'cekrole'], async (ctx) => {
    const target = ctx.mentioned?.[0] || ctx.sender;
    const label = getRoleLabel(target);
    const who = target === ctx.sender ? 'Kamu' : `@${target.split('@')[0]}`;
    await ctx.reply(`🔖 *Jabatan*\n\n${who} saat ini: *${label}*`);
});

// ─── CO-CREATOR ─────────────────────────────────────────────────────────────
reg(['creator', 'infocreator'], async (ctx) => {
    const info = getCreatorInfo();
    const coList = listCoCreators();
    const lines = [
        `╔══════════════════════════╗`,
        `║  👑  *CREATOR INFO*`,
        `╚══════════════════════════╝`,
        ``,
        `🌟 *Primary Creator*`,
        `┗ +${info.number} _(${info.name})_`,
    ];
    if (coList.length > 0) {
        lines.push(``, `🌟 *Co-Creator (${coList.length})*`);
        coList.forEach((c, i) => lines.push(`┗ ${i+1}. +${c.number}`));
    } else {
        lines.push(``, `_Belum ada Co-Creator._`);
    }
    await ctx.reply(lines.join('\n'));
});

reg(['addcreator'], async (ctx) => {
    if (!ctx.isCreator) return ctx.reply('❌ Hanya *Primary Creator* yang bisa menambah Co-Creator.');
    const target = ctx.mentioned?.[0] || (ctx.args?.[0] ? `${ctx.args[0].replace(/[^0-9]/g,'')}@s.whatsapp.net` : null);
    if (!target) return ctx.reply(`📌 Cara pakai: *${settings.prefix}addcreator @tag* atau *${settings.prefix}addcreator 628xxx*`);
    const result = addCoCreator(target, ctx.sender);
    if (!result.ok) return ctx.reply(`❌ ${result.reason}`);
    await ctx.reply(`✅ @${target.split('@')[0]} berhasil dijadikan *Co-Creator*. 🌟`);
});

reg(['delcreator', 'removecreator'], async (ctx) => {
    if (!ctx.isCreator) return ctx.reply('❌ Hanya *Primary Creator* yang bisa menghapus Co-Creator.');
    const target = ctx.mentioned?.[0] || (ctx.args?.[0] ? `${ctx.args[0].replace(/[^0-9]/g,'')}@s.whatsapp.net` : null);
    if (!target) return ctx.reply(`📌 Cara pakai: *${settings.prefix}delcreator @tag*`);
    const result = removeCoCreator(target, ctx.sender);
    if (!result.ok) return ctx.reply(`❌ ${result.reason}`);
    await ctx.reply(`✅ @${target.split('@')[0]} sudah dicabut dari jabatan *Co-Creator*.`);
});

reg(['listcreator', 'daftarcreator'], async (ctx) => {
    const coList = listCoCreators();
    const info   = getCreatorInfo();
    const lines  = [`🌟 *Daftar Creator*`, ``, `👑 Primary: +${info.number} _(${info.name})_`];
    if (coList.length === 0) {
        lines.push('', '_Belum ada Co-Creator._');
    } else {
        lines.push('', `🌟 Co-Creator (${coList.length}):`);
        coList.forEach((c, i) => lines.push(`${i+1}. +${c.number}`));
    }
    await ctx.reply(lines.join('\n'));
});

// ─── ADDLIMIT — tambah limit media manual (owner/creator) ───────────────────
reg(['addlimit', 'tambablimit'], async (ctx) => {
    if (!ctx.isOwner) return ctx.reply('❌ Hanya *Owner* atau *Creator* yang bisa menambah limit.');
    const target = ctx.mentioned?.[0] || (ctx.args?.[0] ? `${ctx.args[0].replace(/[^0-9]/g,'')}@s.whatsapp.net` : null);
    const amount = parseInt(ctx.args?.[ctx.mentioned?.[0] ? 0 : 1]) || 1;
    if (!target) return ctx.reply(`📌 Cara pakai: *${settings.prefix}addlimit @tag [jumlah]*\nContoh: *${settings.prefix}addlimit @user 5*`);
    const result = addLimitManual(target, amount);
    await ctx.reply(
        `✅ *+${amount} limit media* ditambahkan ke @${target.split('@')[0]}.\n` +
        `📊 Sisa limit hari ini: *${Math.max(0, result.max - result.newUsed)}/${result.max}*`
    );
});

// ─── ADDGOLD — tambah gold RPG manual (owner/creator) ───────────────────────
reg(['addgold', 'tambahgold', 'givegold'], async (ctx) => {
    if (!ctx.isOwner) return ctx.reply('❌ Hanya *Owner* atau *Creator* yang bisa menambah gold.');
    const target = ctx.mentioned?.[0] || (ctx.args?.[0] && !parseInt(ctx.args[0])
        ? `${ctx.args[0].replace(/[^0-9]/g,'')}@s.whatsapp.net`
        : null);
    const amount = parseInt(ctx.args?.[ctx.mentioned?.[0] ? 0 : 1]) || 0;
    if (!target || amount <= 0) {
        return ctx.reply(`📌 Cara pakai: *${settings.prefix}addgold @tag [jumlah]*\nContoh: *${settings.prefix}addgold @user 1000*`);
    }
    const char = getChar(target);
    if (!char) return ctx.reply(`❌ @${target.split('@')[0]} belum punya karakter RPG.`);
    char.gold += amount;
    saveChar(target, char);
    await ctx.reply(
        `✅ *+${amount.toLocaleString()} gold* diberikan ke @${target.split('@')[0]}.\n` +
        `💰 Total gold sekarang: *${char.gold.toLocaleString()} gold*`
    );
});

// ─── BUYLIMIT — beli limit tambahan pakai gold (user biasa) ─────────────────
reg(['buylimit', 'belilimit', 'buylimits'], async (ctx) => {
    const result = buyMediaLimit(ctx.sender);
    if (!result.ok) return ctx.reply(`❌ ${result.reason}`);
    await ctx.reply(
        `✅ Berhasil membeli *1 limit media tambahan*!\n` +
        `💰 Gold terpakai: *${result.cost} gold*\n` +
        `💳 Sisa gold: *${result.sisaGold.toLocaleString()} gold*\n\n` +
        `Sekarang kamu bisa pakai fitur media lagi.`
    );
});

// ─── CEKLIMIT — cek sisa limit harian (siapapun) ────────────────────────────
reg(['ceklimit', 'mylimit', 'limitku', 'sisalimit'], async (ctx) => {
    await ctx.reply(`📊 *Status Limit Media Harian*\n\n${limitStatusText(ctx.sender)}`);
});

// ─── AUTOREAD ────────────────────────────────────────────────────────────────
reg(['autoread', 'autobaca', 'autolihat'], async (ctx) => {
    const arg = (ctx.args?.[0] || '').toLowerCase();
    if (!['on', 'off', 'aktif', 'nonaktif'].includes(arg)) {
        return ctx.reply(
            `📌 *Autoread* — bot otomatis centang biru setiap pesan masuk\n\n` +
            `Status sekarang: *${isAutoread(ctx.jid) ? '✅ ON' : '❌ OFF'}*\n\n` +
            `Ketik *.autoread on* atau *.autoread off* untuk ubah.`
        );
    }
    const val = arg === 'on' || arg === 'aktif';
    setAutoread(ctx.jid, val);
    await ctx.reply(`${val ? '✅' : '❌'} *Autoread* berhasil di-${val ? 'aktifkan' : 'nonaktifkan'}.`);
});

// ─── AUTOTYPING ──────────────────────────────────────────────────────────────
reg(['autotyping', 'automengetik', 'autoketik'], async (ctx) => {
    const arg = (ctx.args?.[0] || '').toLowerCase();
    if (!['on', 'off', 'aktif', 'nonaktif'].includes(arg)) {
        return ctx.reply(
            `📌 *Autotyping* — bot tampil "mengetik..." sebelum balas pesan\n\n` +
            `Status sekarang: *${isAutotyping(ctx.jid) ? '✅ ON' : '❌ OFF'}*\n\n` +
            `Ketik *.autotyping on* atau *.autotyping off* untuk ubah.`
        );
    }
    const val = arg === 'on' || arg === 'aktif';
    setAutotyping(ctx.jid, val);
    await ctx.reply(`${val ? '✅' : '❌'} *Autotyping* berhasil di-${val ? 'aktifkan' : 'nonaktifkan'}.`);
});

// ─── GOJO AI — mode chat AI ala Gojo Satoru, on/off per chat/grup ───────────
// Default ON (lihat lib/gojoAi.js). Hanya Admin grup/Owner/Creator yang
// boleh ubah. Di grup: bot cuma respon kalau di-mention/di-reply. Di DM:
// bot respon semua chat biasa. Logic trigger & pemanggilan AI ada di
// lib/gojoAi.js — file ini cuma toggle on/off-nya.
reg(['gojoai'], async (ctx) => {
    if (!ctx.isAdmin && !ctx.isOwner && !ctx.isCreator) {
        return ctx.reply('❌ Hanya *Admin grup*, *Owner*, atau *Creator* yang bisa mengubah mode ini.');
    }
    const arg = (ctx.args?.[0] || '').toLowerCase();
    if (!['on', 'off', 'aktif', 'nonaktif'].includes(arg)) {
        return ctx.reply(
            `📌 *Gojo AI* — bot balas chat biasa pakai gaya Gojo Satoru (AI)\n\n` +
            `Status sekarang: *${isGojoAiEnabled(ctx.jid) ? '✅ ON' : '❌ OFF'}*\n` +
            `• Di grup: bot cuma respon kalau di-*mention* atau di-*reply*.\n` +
            `• Di DM: bot respon semua chat biasa.\n\n` +
            `Ketik *.gojoai on* atau *.gojoai off* untuk ubah.`
        );
    }
    const val = arg === 'on' || arg === 'aktif';
    setGojoAiEnabled(ctx.jid, val);
    await ctx.reply(`${val ? '✅' : '❌'} *Gojo AI* berhasil di-${val ? 'aktifkan' : 'nonaktifkan'} untuk chat ini.`);
});

// ─── SELF MODE ────────────────────────────────────────────────────────────────
// Bot hanya merespon pesan dari owner/nomor bot sendiri.
// Hanya owner/creator yang bisa ubah ini.
reg(['self', 'selfmode', 'modeself'], async (ctx) => {
    if (!ctx.isOwner) return ctx.reply('❌ Hanya *Owner/Creator* yang bisa mengubah mode bot.');
    const arg = (ctx.args?.[0] || '').toLowerCase();
    if (!['on', 'off'].includes(arg)) {
        return ctx.reply(
            `📌 *Self Mode* — bot hanya respon ke owner/nomor bot sendiri\n\n` +
            `Status sekarang: *${settings.selfMode ? '✅ ON (Self)' : '❌ OFF (Public)'}*\n\n` +
            `Ketik *.self on* atau *.self off* untuk ubah.`
        );
    }
    const val = arg === 'on';
    settings.selfMode = val;
    const cfg = botCfg();
    cfg.selfMode = val;
    saveBotCfg();
    await ctx.reply(
        val
            ? `✅ *Self Mode ON* — bot sekarang hanya merespon owner & nomor bot sendiri.`
            : `❌ *Self Mode OFF* — bot kembali merespon semua orang.`
    );
});

// ─── PUBLIC / PRIVATE MODE ────────────────────────────────────────────────────
reg(['public', 'publicmode', 'modepublic', 'setpublic'], async (ctx) => {
    if (!ctx.isOwner) return ctx.reply('❌ Hanya *Owner/Creator* yang bisa mengubah mode bot.');
    settings.public = true;
    settings.selfMode = false;
    const cfg = botCfg(); cfg.selfMode = false; cfg.public = true; saveBotCfg();
    await ctx.reply('✅ *Mode Public* — bot sekarang bisa digunakan semua orang.');
});

reg(['private', 'privatemode', 'modeprivate', 'setprivate'], async (ctx) => {
    if (!ctx.isOwner) return ctx.reply('❌ Hanya *Owner/Creator* yang bisa mengubah mode bot.');
    settings.public = false;
    settings.selfMode = true;
    const cfg = botCfg(); cfg.selfMode = true; cfg.public = false; saveBotCfg();
    await ctx.reply('✅ *Mode Private* — bot sekarang hanya merespon owner & nomor bot sendiri.');
});

// ─── SEWA BOT ─────────────────────────────────────────────────────────────────
reg(['sewa', 'sewakan', 'sewagrup'], async (ctx) => sewaCommands.sewa(ctx));
reg(['ceksewa', 'infosewa', 'statussewa'], async (ctx) => sewaCommands.ceksewa(ctx));
reg(['delsewa', 'hapussewa', 'removesewa'], async (ctx) => sewaCommands.delsewa(ctx, ctx.sock));
reg(['listsewa', 'daftarsewa', 'sewaall'], async (ctx) => sewaCommands.listsewa(ctx));
reg(['extsewa', 'perpanjangsewa', 'renewsewa', 'addsewa'], async (ctx) => sewaCommands.extsewa(ctx));
reg(['hargasewa', 'pricesewa', 'infoharga'], async (ctx) => sewaCommands.hargasewa(ctx));
reg(['gantihargasewa', 'sethargasewa', 'ubahhargasewa'], async (ctx) => sewaCommands.gantihargasewa(ctx));
reg(['sewamode', 'modesewabot', 'togglesewa'], async (ctx) => sewaCommands.sewamode(ctx));

// ─── BRAT ─────────────────────────────────────────────────────────────────────
// Variant brat dipangkas jadi 3 command ini saja (2026-07-07) — semua
// variant lain (bratimg/brathd/bratanime/bratpatrick/bratsquidward/
// bratgojo/bratvermeil/bratvid/bratvid2/bratgojovid/bratvermeilvid) dan
// menu picker-nya (bratmenu/bratlist) sudah dihapus dari bratCommands.js.
reg(['brat'], async (ctx) => bratGenerate(ctx, 'brat'));
reg(['bratgreen'], async (ctx) => bratGenerate(ctx, 'bratgreen'));
reg(['bratwhite'], async (ctx) => bratGenerate(ctx, 'bratwhite'));

// ─── IQC ──────────────────────────────────────────────────────────────────────
reg(['iqc', 'iphonequote', 'iphoneqc', 'imessagequote'], async (ctx) => iqc(ctx));
// OFF = bot auto-keluar dari grup yang dimasukkan orang lain (bukan owner)
// ON  = bot tetap di grup dan bisa digunakan (default)
reg(['autojoin', 'automasukgrup', 'autojoingrup'], async (ctx) => {
    if (!ctx.isOwner) return ctx.reply('❌ Hanya *Owner/Creator* yang bisa mengubah setting autojoin.');
    const arg = (ctx.args?.[0] || '').toLowerCase();
    const cfg = botCfg();
    if (!['on', 'off'].includes(arg)) {
        return ctx.reply(
            `📌 *Autojoin* — kontrol apakah bot keluar otomatis dari grup yang tidak diizinkan\n\n` +
            `Status sekarang: *${cfg.autojoin !== false ? '✅ ON (bot stay di semua grup)' : '❌ OFF (bot auto-keluar jika bukan owner yg masukkan)'}*\n\n` +
            `Ketik *.autojoin on* atau *.autojoin off* untuk ubah.`
        );
    }
    const val = arg === 'on';
    cfg.autojoin = val;
    saveBotCfg();
    await ctx.reply(
        val
            ? `✅ *Autojoin ON* — bot akan stay di semua grup yang dimasukkan.`
            : `❌ *Autojoin OFF* — bot akan otomatis keluar dari grup jika bukan owner yang memasukkan.`
    );
});

reg(['whoami', 'nomorku'], async (ctx) => {
    const num = (ctx.sender || '').split('@')[0];
    if (isLidJid(ctx.sender)) {
        // FIX: dulu angka di depan "@lid" ditampilkan seolah-olah nomor HP
        // asli (padahal itu ID internal acak dari WhatsApp, bukan nomor
        // HP) — sekarang dijelaskan dengan jujur, supaya user tidak
        // mengira itu nomornya, dan supaya kalau identitas ini terlihat
        // beda di lain waktu, user paham kenapa (keterbatasan WhatsApp,
        // bukan bug di nomor mereka).
        return ctx.reply(
`🪪 *INFO AKUNMU*

⚠️ WhatsApp mengirim akunmu sebagai ID privat (*LID*), bukan nomor HP biasa.
◈ *ID*    : \`${num}\` _(bukan nomor HP asli)_
◈ *JID*   : \`${ctx.sender}\`
◈ *Chat*  : ${ctx.isGroup ? '👥 Grup' : '💬 Private'}

_Ini keterbatasan dari sistem WhatsApp sendiri, bukan kesalahan bot. Coba kirim pesan biasa (bukan reply) kalau ingin bot mengenali nomor HP aslimu._`
        );
    }
    await ctx.reply(
`🪪 *INFO NOMORMU*

◈ *Nomor* : +${num}
◈ *JID*   : \`${ctx.sender}\`
◈ *Chat*  : ${ctx.isGroup ? '👥 Grup' : '💬 Private'}`
    );
});

reg(['runtime', 'uptime'], async (ctx) => {
    const topCmds = getTopCommands(5).map(([cmd, n], i) => `  ${i+1}. \`${cmd}\` — ${n}x`).join('\n');
    await ctx.reply(
`⏱️ *BOT RUNTIME*

◈ *Aktif sejak* : ${fmtDuration(Date.now() - BOT_START_TIME)} lalu
◈ *Users RPG*   : ${countUsers()} orang
◈ *Grup aktif*  : ${countGroups()} grup
◈ *Total cmd*   : ${getTotalCommandsRan()} kali

🏆 *Top 5 Command Terpopuler:*
${topCmds || '  _(belum ada data)_'}`
    );
});

reg(['jam', 'waktuserver', 'servertime'], async (ctx) => infoTools.serverTime(ctx.reply));

// ── MEDIA ─────────────────────────────────────────────────────────────────
reg(['repost', 'kirimulang'], async (ctx) => mediaCommands.repostLast(ctx.sock, ctx.reply, ctx.jid, ctx.sender));
reg(['mediainfo', 'infomedia'], async (ctx) => mediaCommands.mediaInfo(ctx.reply, ctx.jid));
reg(['sticker', 'stiker', 's'], async (ctx) => mediaCommands.quoteAsSticker(ctx.reply));
reg(['pp', 'fotoprofile', 'profilepic'], async (ctx) => mediaCommands.profilePicInfo(ctx.sock, ctx.reply, ctx.jid, ctx.mentioned, ctx.sender));
reg(['ppgrup', 'fotogrup', 'grouppic'], async (ctx) => mediaCommands.getGroupPic(ctx.sock, ctx.reply, ctx.jid, ctx.sender));

// ── RPG: GATHERING / CRAFTING / GAMBLING / TRAINING (batch 3) ───────────
reg(['mine', 'tambang', 'menambang'], async (ctx) => rpgCommands3.mine(ctx.reply, ctx.sender));
reg(['fish', 'mancing', 'memancing'], async (ctx) => rpgCommands3.fish(ctx.reply, ctx.sender));
reg(['craft', 'crafting', 'buatitem'], async (ctx) => rpgCommands3.craft(ctx.reply, ctx.sender, ctx.args));
reg(['refine', 'tingkatkan', 'upgrade'], async (ctx) => rpgCommands3.refine(ctx.reply, ctx.sender, ctx.args));
reg(['gamble', 'taruhan', 'judigold'], async (ctx) => rpgCommands3.gamble(ctx.reply, ctx.sender, ctx.args));
reg(['lottery', 'lotre', 'undian'], async (ctx) => rpgCommands3.lottery(ctx.reply, ctx.sender));
reg(['train', 'latihan', 'training'], async (ctx) => rpgCommands3.train(ctx.reply, ctx.sender, ctx.args));
reg(['prestige', 'naikkelas', 'reborn'], async (ctx) => rpgCommands3.prestige(ctx.reply, ctx.sender));

// ── ADMIN: RULES / NOTES / POLL / BAN / AUTOREPLY (batch 2) ──────────────
reg(['setrules', 'aturanaturgrup'], async (ctx) => adminCommands2.setRules(ctx.reply, ctx.jid, ctx.args, ctx.isAdmin));
reg(['rules', 'aturan', 'aturangrup'], async (ctx) => adminCommands2.showRules(ctx.reply, ctx.jid));
reg(['addnote', 'tambahnote', 'catat'], async (ctx) => adminCommands2.addNote(ctx.reply, ctx.jid, ctx.args, ctx.isAdmin));
reg(['notes', 'listnote', 'catatan'], async (ctx) => adminCommands2.listNotes(ctx.reply, ctx.jid));
reg(['delnote', 'hapusnote', 'deletenote'], async (ctx) => adminCommands2.deleteNote(ctx.reply, ctx.jid, ctx.args, ctx.isAdmin));
reg(['pollnative', 'pollwa', 'jajakpendapat'], async (ctx) => adminCommands2.createPoll(ctx.sock, ctx.reply, ctx.jid, ctx.msg, ctx.args));
reg(['antidelete', 'antihapus'], async (ctx) => adminCommands2.antidelete(ctx.reply, ctx.jid, ctx.args, ctx.isAdmin));
reg(['statsgrupmember', 'infostatsgrup', 'statsmember'], async (ctx) => adminCommands2.groupActivity(ctx.sock, ctx.reply, ctx.jid));
reg(['ban', 'blokirbot', 'blockuser'], async (ctx) => adminCommands2.banUser(ctx.reply, ctx.jid, ctx.mentioned, ctx.isAdmin));
reg(['unban', 'bukablokir', 'unblockuser'], async (ctx) => adminCommands2.unbanUser(ctx.reply, ctx.jid, ctx.mentioned, ctx.isAdmin));
reg(['autoreply', 'aturbalasan', 'setautoreply'], async (ctx) => adminCommands2.setAutoReply(ctx.reply, ctx.jid, ctx.args, ctx.isAdmin));
reg(['listautoreply', 'daftarbalasan'], async (ctx) => adminCommands2.listAutoReply(ctx.reply, ctx.jid));

// ── FUN: BATCH 2 ──────────────────────────────────────────────────────────
reg(['compliment', 'puji', 'pujian'], async (ctx) => funCommands2.compliment(ctx.reply, ctx.mentioned));
reg(['roast', 'roasting', 'sindir'], async (ctx) => funCommands2.roast(ctx.reply, ctx.mentioned));
reg(['pickupline', 'gombalan', 'rayuan'], async (ctx) => funCommands2.pickupLine(ctx.reply));
reg(['nhie', 'neverhaveiever', 'pernahgak'], async (ctx) => funCommands2.neverHaveIEver(ctx.reply));
reg(['storystarter', 'mulaicerita'], async (ctx) => funCommands2.storyStarter(ctx.reply));
reg(['emojipuzzle', 'tebakemoji'], async (ctx) => funCommands2.emojiPuzzle(ctx.reply, ctx.jid));
reg(['jawabemoji', 'answeremoji'], async (ctx) => funCommands2.answerEmoji(ctx.reply, ctx.jid, ctx.args));
reg(['bola8', 'ramalanbola'], async (ctx) => funCommands2.magic8ball(ctx.reply, ctx.args));
reg(['challenge', 'tantangan', 'tantanganharian'], async (ctx) => funCommands2.randomChallenge(ctx.reply));
reg(['wordassoc', 'asosiasikata'], async (ctx) => funCommands2.wordAssociation(ctx.reply, ctx.jid));
reg(['mbti', 'tipemodel'], async (ctx) => funCommands2.mbtiGuess(ctx.reply));
reg(['luckynumberku', 'nomorberuntungku'], async (ctx) => funCommands2.luckyNumber(ctx.reply, ctx.sender));
reg(['mood', 'moodharian', 'dailymood'], async (ctx) => funCommands2.dailyMood(ctx.reply));

// ── TOOLS: MATH BATCH 2 ───────────────────────────────────────────────────
reg(['isprime', 'cekprima'], async (ctx) => mathTools2.isPrime(ctx.reply, ctx.args));
reg(['palindrome', 'cekpalindrome'], async (ctx) => mathTools2.isPalindrome(ctx.reply, ctx.args));
reg(['faktorial', 'factorial'], async (ctx) => mathTools2.factorial(ctx.reply, ctx.args));
reg(['fibonacci', 'fibo'], async (ctx) => mathTools2.fibonacci(ctx.reply, ctx.args));
reg(['gcdlcm', 'fpbkpk'], async (ctx) => mathTools2.gcdLcm(ctx.reply, ctx.args));
reg(['suhulengkap', 'celsiusall'], async (ctx) => mathTools2.celsiusAll(ctx.reply, ctx.args));
reg(['roman', 'romawi'], async (ctx) => mathTools2.toRoman(ctx.reply, ctx.args));
reg(['kuadrat', 'quadratic'], async (ctx) => mathTools2.quadratic(ctx.reply, ctx.args));
reg(['average', 'ratarata'], async (ctx) => mathTools2.average(ctx.reply, ctx.args));
reg(['median'], async (ctx) => mathTools2.median(ctx.reply, ctx.args));

// ── TOOLS: DATE BATCH ──────────────────────────────────────────────────────
reg(['harike', 'dayofweek'], async (ctx) => dateTools.dayOfWeek(ctx.reply, ctx.args));
reg(['sisahari', 'daysuntil', 'countdown'], async (ctx) => dateTools.daysUntil(ctx.reply, ctx.args));
reg(['leapyear', 'tahunkabisat'], async (ctx) => dateTools.isLeapYear(ctx.reply, ctx.args));
reg(['zodiaklahir', 'cekzodiak'], async (ctx) => dateTools.zodiacSign(ctx.reply, ctx.args));

// ── TOOLS: FORMAT BATCH ───────────────────────────────────────────────────
reg(['kapitalkata'], async (ctx) => formatTools.toTitleCase(ctx.reply, ctx.args));
reg(['removespace', 'hapusspasi'], async (ctx) => formatTools.removeSpaces(ctx.reply, ctx.args));
reg(['repeat'], async (ctx) => formatTools.repeatText(ctx.reply, ctx.args));
reg(['charat', 'karakterke'], async (ctx) => formatTools.charAt(ctx.reply, ctx.args));
reg(['textstats', 'statistikteks'], async (ctx) => formatTools.textStats(ctx.reply, ctx.args));

// ── TOOLS: VALIDATOR BATCH ────────────────────────────────────────────────
reg(['validemail'], async (ctx) => validatorTools.validateEmail(ctx.reply, ctx.args));
reg(['validphone', 'ceknomor'], async (ctx) => validatorTools.validatePhone(ctx.reply, ctx.args));
reg(['cekpassword', 'passwordstrength'], async (ctx) => validatorTools.checkPasswordStrength(ctx.reply, ctx.args));

// ── RPG: LOOKUP / INFO (batch 4) ──────────────────────────────────────────
reg(['monster', 'monsterinfo', 'infomonster'], async (ctx) => rpgCommands4.monsterInfo(ctx.reply, ctx.args));
reg(['monsterlist', 'listmonster', 'daftarmonster'], async (ctx) => rpgCommands4.monsterList(ctx.reply, ctx.args));
reg(['iteminfo', 'infoitem', 'detailitem'], async (ctx) => rpgCommands4.itemInfo(ctx.reply, ctx.args));
reg(['weaponlist', 'listweapon', 'daftarweapon', 'daftarsenjata'], async (ctx) => rpgCommands4.weaponList(ctx.reply, ctx.args));
reg(['armorlist', 'listarmor', 'daftarzirah', 'daftararmor'], async (ctx) => rpgCommands4.armorList(ctx.reply, ctx.args));
reg(['compare', 'bandingkan', 'comparepower'], async (ctx) => rpgCommands4.comparePower(ctx.reply, ctx.sender, ctx.mentioned));
reg(['classinfo', 'infoclass', 'detailclass'], async (ctx) => rpgCommands4.classInfo(ctx.reply, ctx.args));
reg(['hp', 'cekhp', 'checkhp'], async (ctx) => rpgCommands4.checkHp(ctx.reply, ctx.sender));
reg(['gold', 'cekgold', 'checkgold', 'saldo'], async (ctx) => rpgCommands4.checkGold(ctx.reply, ctx.sender));
reg(['level', 'ceklevel', 'checklevel', 'lvl'], async (ctx) => rpgCommands4.checkLevel(ctx.reply, ctx.sender));

// ── EXTRA ALIASES TO ROUND OUT FEATURE COVERAGE ──────────────────────────
reg(['cekprofil', 'lihatprofil', 'myprofile', 'akun'], async (ctx) => rpgCommands.showProfile(ctx.reply, ctx.sender, ctx.msg, ctx.mentioned));
reg(['tas', 'cektas', 'myinventory', 'mybag'], async (ctx) => rpgCommands.showInventory(ctx.reply, ctx.sender));
reg(['pakaiweapon', 'equipweapon', 'gunakan'], async (ctx) => rpgCommands.equipItem(ctx.reply, ctx.sender, ctx.args));
reg(['lepasweapon', 'unequipweapon'], async (ctx) => rpgCommands.unequipItem(ctx.reply, ctx.sender, ctx.args));
reg(['minumpotion', 'usepotion', 'pakaipotion'], async (ctx) => rpgCommands.useItem(ctx.reply, ctx.sender, ctx.args));
reg(['serbu', 'attack', 'hajar'], async (ctx) => rpgCommands.hunt(ctx.reply, ctx.sender));
reg(['tarung', 'fight', 'challengepvp'], async (ctx) => rpgCommands.battle(ctx.reply, ctx.sender, ctx.mentioned));
reg(['healhp', 'pulihkan', 'sembuh'], async (ctx) => rpgCommands.rest(ctx.reply, ctx.sender));
reg(['raidboss', 'seranggboss', 'fightraid'], async (ctx) => rpgCommands2.fightBoss(ctx.reply, ctx.sender, ctx.args));
reg(['masuk', 'enterdungeon', 'gerbang'], async (ctx) => rpgCommands2.enterDungeon(ctx.reply, ctx.sender, ctx.args));
reg(['cektoko', 'lihattoko', 'viewstore'], async (ctx) => rpgCommands2.showShop(ctx.reply, ctx.args));
reg(['purchase', 'belanjaitem'], async (ctx) => rpgCommands2.buyItem(ctx.reply, ctx.sender, ctx.args));
reg(['jualitem', 'sellitem'], async (ctx) => rpgCommands2.sellItem(ctx.reply, ctx.sender, ctx.args));
reg(['absenharian', 'klaimharian', 'rewardharian'], async (ctx) => rpgCommands2.dailyReward(ctx.reply, ctx.sender));
reg(['bekerja', 'cariuang', 'ngumpulgold'], async (ctx) => rpgCommands2.work(ctx.reply, ctx.sender, ctx.args));
reg(['setor', 'simpanbank', 'depositbank'], async (ctx) => rpgCommands2.bankDeposit(ctx.reply, ctx.sender, ctx.args));
reg(['ambilbank', 'withdrawbank', 'tarikbank'], async (ctx) => rpgCommands2.bankWithdraw(ctx.reply, ctx.sender, ctx.args));
reg(['kirimgoldke', 'sendgold', 'transfergold'], async (ctx) => rpgCommands2.transfer(ctx.reply, ctx.sender, ctx.mentioned, ctx.args));
reg(['merampok', 'mencuri', 'steal'], async (ctx) => rpgCommands2.rob(ctx.reply, ctx.sender, ctx.mentioned));
reg(['cekpet', 'mypets', 'listpets'], async (ctx) => rpgCommands2.petInfo(ctx.reply, ctx.sender));
reg(['gantipetaktif', 'activatepet'], async (ctx) => rpgCommands2.setPet(ctx.reply, ctx.sender, ctx.args));
reg(['daftarmisi', 'listquest', 'misiku'], async (ctx) => rpgCommands2.showQuests(ctx.reply, ctx.sender));
reg(['ambilreward', 'claimreward', 'klaimreward'], async (ctx) => rpgCommands2.claimQuest(ctx.reply, ctx.sender, ctx.args));
reg(['lencanaku', 'myachievements', 'badge'], async (ctx) => rpgCommands2.showAchievements(ctx.reply, ctx.sender));
reg(['papanperingkat', 'globaltop', 'rankingglobal'], async (ctx) => rpgCommands2.showRanking(ctx.reply));
reg(['papanskor', 'scoreboard'], async (ctx) => rpgCommands2.leaderboard(ctx.reply, ctx.args));
reg(['menikahi', 'lamar', 'propose'], async (ctx) => rpgCommands2.marry(ctx.reply, ctx.sender, ctx.mentioned));
reg(['putuscinta', 'breakup', 'akhiripernikahan'], async (ctx) => rpgCommands2.divorce(ctx.reply, ctx.sender));
reg(['nambang', 'mengeruk', 'digging'], async (ctx) => rpgCommands3.mine(ctx.reply, ctx.sender));
reg(['memancingikan', 'gofishing'], async (ctx) => rpgCommands3.fish(ctx.reply, ctx.sender));
reg(['bikinitem', 'forge', 'tempa'], async (ctx) => rpgCommands3.craft(ctx.reply, ctx.sender, ctx.args));
reg(['perkuatitem', 'enhance', 'upgradeitem'], async (ctx) => rpgCommands3.refine(ctx.reply, ctx.sender, ctx.args));
reg(['bettinggold', 'bet', 'pasangtaruhan'], async (ctx) => rpgCommands3.gamble(ctx.reply, ctx.sender, ctx.args));
reg(['beliundian', 'tiketlotre', 'buylottery'], async (ctx) => rpgCommands3.lottery(ctx.reply, ctx.sender));
reg(['latihangym', 'workout', 'gym'], async (ctx) => rpgCommands3.train(ctx.reply, ctx.sender, ctx.args));
reg(['naikprestige', 'rebornchar', 'ascend'], async (ctx) => rpgCommands3.prestige(ctx.reply, ctx.sender));
reg(['cekaturangrup', 'lihataturan'], async (ctx) => adminCommands2.showRules(ctx.reply, ctx.jid));
reg(['simpancatatan', 'savenote'], async (ctx) => adminCommands2.addNote(ctx.reply, ctx.jid, ctx.args, ctx.isAdmin));
reg(['lihatcatatan', 'viewnotes'], async (ctx) => adminCommands2.listNotes(ctx.reply, ctx.jid));
reg(['buatpolling', 'votingbuat'], async (ctx) => adminCommands2.createPoll(ctx.sock, ctx.reply, ctx.jid, ctx.msg, ctx.args));
reg(['statistikgrup', 'infoaktivitas'], async (ctx) => adminCommands2.groupActivity(ctx.sock, ctx.reply, ctx.jid));
reg(['blokirpengguna', 'blockmember'], async (ctx) => adminCommands2.banUser(ctx.reply, ctx.jid, ctx.mentioned, ctx.isAdmin));
reg(['bukablokirpengguna', 'unblockmember'], async (ctx) => adminCommands2.unbanUser(ctx.reply, ctx.jid, ctx.mentioned, ctx.isAdmin));
reg(['aturautobalas', 'configautoreply'], async (ctx) => adminCommands2.setAutoReply(ctx.reply, ctx.jid, ctx.args, ctx.isAdmin));
reg(['lihatautobalas', 'viewautoreply'], async (ctx) => adminCommands2.listAutoReply(ctx.reply, ctx.jid));
reg(['katasemangat', 'motivation', 'penyemangat'], async (ctx) => funCommands.quote(ctx.reply));
reg(['faktamenarik', 'funfact'], async (ctx) => funCommands.fact(ctx.reply));
reg(['puzzleotak', 'brainteaser'], async (ctx) => funCommands.riddle(ctx.reply, ctx.jid));
reg(['kejujuran', 'truthquestion'], async (ctx) => funCommands.truth(ctx.reply));
reg(['tantanganfun', 'daretask'], async (ctx) => funCommands.dare(ctx.reply));
reg(['gambartebak', 'pictureguess'], async (ctx) => funCommands.tebakGambar(ctx.reply, ctx.jid));
reg(['pantunlucu', 'rhyme'], async (ctx) => funCommands.pantun(ctx.reply));
reg(['cekzodiakku', 'myzodiac'], async (ctx) => funCommands.horoscope(ctx.reply, ctx.args));
reg(['flipcoin', 'lempar'], async (ctx) => funCommands.coinFlip(ctx.reply));
reg(['lemparkandadu', 'rolldice'], async (ctx) => funCommands.rollDice(ctx.reply, ctx.args));
reg(['suitan', 'suit'], async (ctx) => funCommands.rps(ctx.reply, ctx.args));
reg(['mesinslot', 'spinslot'], async (ctx) => funCommands.slot(ctx.reply, ctx.sender));
reg(['mulaitebakangka', 'startguess'], async (ctx) => funCommands.tebakAngka(ctx.reply, ctx.jid));
reg(['jawabangka', 'guessanswer'], async (ctx) => funCommands.guessNumber(ctx.reply, ctx.jid, ctx.args));
reg(['pilihsalahsatu', 'eitheror'], async (ctx) => funCommands.wouldYouRather(ctx.reply));
reg(['cekjodohku', 'lovematch'], async (ctx) => funCommands.checkJodoh(ctx.reply, ctx.sender, ctx.mentioned));
reg(['kartutarothariini', 'dailytarot'], async (ctx) => funCommands.tarotCard(ctx.reply));
reg(['kuekeberuntungan', 'luckycookie'], async (ctx) => funCommands.fortuneCookie(ctx.reply));
reg(['kalkulatorjodoh', 'lovepercent'], async (ctx) => funCommands.hitungCinta(ctx.reply, ctx.sender, ctx.mentioned, ctx.args));
reg(['hurufbesar', 'majukan'], async (ctx) => textTools.upper(ctx.reply, ctx.args));
reg(['hurufkecil', 'minorkan'], async (ctx) => textTools.lower(ctx.reply, ctx.args));
reg(['balikteks', 'mirrortext'], async (ctx) => textTools.reverse(ctx.reply, ctx.args));
reg(['encodebinary', 'tobinary2'], async (ctx) => textTools.toBinary(ctx.reply, ctx.args));
reg(['decodebinary', 'frombinary2'], async (ctx) => textTools.fromBinary(ctx.reply, ctx.args));
reg(['encodebase64', 'tobase642'], async (ctx) => textTools.toBase64(ctx.reply, ctx.args));
reg(['decodebase64', 'frombase642'], async (ctx) => textTools.fromBase64(ctx.reply, ctx.args));
reg(['encodehex', 'tohex2'], async (ctx) => textTools.toHex(ctx.reply, ctx.args));
reg(['decodehex', 'fromhex2'], async (ctx) => textTools.fromHex(ctx.reply, ctx.args));
reg(['sandirot13', 'cipherrot13'], async (ctx) => textTools.rot13(ctx.reply, ctx.args));
reg(['bahasaleet', 'leetify'], async (ctx) => textTools.leet(ctx.reply, ctx.args));
reg(['hurufselangseling', 'zigzagcase'], async (ctx) => textTools.alternating(ctx.reply, ctx.args));
reg(['hitungkatakalimat', 'wordcounter'], async (ctx) => textTools.countWords(ctx.reply, ctx.args));
reg(['kalkulatorhitung', 'mathcalc'], async (ctx) => mathTools.calc(ctx.reply, ctx.args));
reg(['hitungpersen', 'percentcalc'], async (ctx) => mathTools.percent(ctx.reply, ctx.args));
reg(['hitungbmi', 'bmicalc'], async (ctx) => mathTools.bmi(ctx.reply, ctx.args));
reg(['cekkurs', 'kursinfo'], async (ctx) => mathTools.convertCurrencyNote(ctx.reply));
reg(['hitungusia', 'agecounter'], async (ctx) => mathTools.ageCalc(ctx.reply, ctx.args));
reg(['konversipanjang2', 'lengthconv'], async (ctx) => converterTools.convertLength(ctx.reply, ctx.args));
reg(['konversiberat2', 'weightconv'], async (ctx) => converterTools.convertWeight(ctx.reply, ctx.args));
reg(['konversisuhu2', 'tempconv'], async (ctx) => converterTools.convertTemp(ctx.reply, ctx.args));
reg(['buatpasswordku', 'newpassword'], async (ctx) => generatorTools.genPassword(ctx.reply, ctx.args));
reg(['buatuuid', 'newuuid'], async (ctx) => generatorTools.genUUID(ctx.reply));
reg(['pilihanrandom', 'randomchoice'], async (ctx) => generatorTools.pickRandom(ctx.reply, ctx.args));
reg(['acakdaftar', 'shufflelist'], async (ctx) => generatorTools.shuffleList(ctx.reply, ctx.args));
reg(['cekping', 'pingbot'], async (ctx) => infoTools.ping(ctx.reply));
reg(['siapakahaku', 'mynumber'], async (ctx) => infoTools.whoami(ctx.reply, ctx.sender));
reg(['lamabotaktif', 'botuptime'], async (ctx) => infoTools.runtime(ctx.reply, BOT_START_TIME));
reg(['waktusekarang', 'currenttime'], async (ctx) => infoTools.serverTime(ctx.reply));
reg(['cekprima2', 'primecheck'], async (ctx) => mathTools2.isPrime(ctx.reply, ctx.args));
reg(['cekpalindrome2', 'palindromecheck'], async (ctx) => mathTools2.isPalindrome(ctx.reply, ctx.args));
reg(['hitungfaktorial', 'factorialcalc'], async (ctx) => mathTools2.factorial(ctx.reply, ctx.args));
reg(['urutanfibonacci', 'fibsequence'], async (ctx) => mathTools2.fibonacci(ctx.reply, ctx.args));
reg(['hitungfpbkpk', 'gcdlcmcalc'], async (ctx) => mathTools2.gcdLcm(ctx.reply, ctx.args));
reg(['konversisuhulengkap', 'fullcelsius'], async (ctx) => mathTools2.celsiusAll(ctx.reply, ctx.args));
reg(['angkaromawi', 'romannumeral'], async (ctx) => mathTools2.toRoman(ctx.reply, ctx.args));
reg(['rumuskuadrat', 'quadraticformula'], async (ctx) => mathTools2.quadratic(ctx.reply, ctx.args));
reg(['hitungratarata', 'averagecalc'], async (ctx) => mathTools2.average(ctx.reply, ctx.args));
reg(['hitungmedian', 'mediancalc'], async (ctx) => mathTools2.median(ctx.reply, ctx.args));
reg(['cekharike', 'whatday'], async (ctx) => dateTools.dayOfWeek(ctx.reply, ctx.args));
reg(['hitungsisahari', 'remainingdays'], async (ctx) => dateTools.daysUntil(ctx.reply, ctx.args));
reg(['cekkabisat', 'leapcheck'], async (ctx) => dateTools.isLeapYear(ctx.reply, ctx.args));
reg(['cekzodiaklahir', 'birthzodiac'], async (ctx) => dateTools.zodiacSign(ctx.reply, ctx.args));
reg(['judulkata', 'capitalizetitle'], async (ctx) => formatTools.toTitleCase(ctx.reply, ctx.args));
reg(['hapusspasi2', 'trimallspace'], async (ctx) => formatTools.removeSpaces(ctx.reply, ctx.args));
reg(['ulangiteks', 'repeatstring'], async (ctx) => formatTools.repeatText(ctx.reply, ctx.args));
reg(['ambilkarakter', 'getchar'], async (ctx) => formatTools.charAt(ctx.reply, ctx.args));
reg(['statistikkalimat', 'sentencestats'], async (ctx) => formatTools.textStats(ctx.reply, ctx.args));
reg(['cekformatmail', 'emailcheck'], async (ctx) => validatorTools.validateEmail(ctx.reply, ctx.args));
reg(['cekformatnomor', 'phonecheck'], async (ctx) => validatorTools.validatePhone(ctx.reply, ctx.args));
reg(['kekuatanpassword', 'pwstrength'], async (ctx) => validatorTools.checkPasswordStrength(ctx.reply, ctx.args));
reg(['pujimember', 'givecompliment'], async (ctx) => funCommands2.compliment(ctx.reply, ctx.mentioned));
reg(['sindirmember', 'giveroast'], async (ctx) => funCommands2.roast(ctx.reply, ctx.mentioned));
reg(['rayuangombal', 'flirtline'], async (ctx) => funCommands2.pickupLine(ctx.reply));
reg(['pernahkahkamu', 'haveyouever'], async (ctx) => funCommands2.neverHaveIEver(ctx.reply));
reg(['pembukacerita', 'tellstory'], async (ctx) => funCommands2.storyStarter(ctx.reply));
reg(['tebakemojifilm', 'emojimovie'], async (ctx) => funCommands2.emojiPuzzle(ctx.reply, ctx.jid));
reg(['jawabantebakemoji', 'emojianswer'], async (ctx) => funCommands2.answerEmoji(ctx.reply, ctx.jid, ctx.args));
reg(['bola8magic', 'eightball'], async (ctx) => funCommands2.magic8ball(ctx.reply, ctx.args));
reg(['tantanganrandom', 'dailychallenge'], async (ctx) => funCommands2.randomChallenge(ctx.reply));
reg(['asosiasikatabaru', 'wordlink'], async (ctx) => funCommands2.wordAssociation(ctx.reply, ctx.jid));
reg(['tebakmbti', 'mbtitoday'], async (ctx) => funCommands2.mbtiGuess(ctx.reply));
reg(['nomorhoki', 'luckynum'], async (ctx) => funCommands2.luckyNumber(ctx.reply, ctx.sender));
reg(['moodku', 'mytodaymood'], async (ctx) => funCommands2.dailyMood(ctx.reply));

// ── FUN/GAME BARU (funCommands3) ─────────────────────────────────────────
reg(['trivia'], async (ctx) => funCommands3.trivia(ctx.reply, ctx.jid));
reg(['jawabtrivia'], async (ctx) => funCommands3.answerTrivia(ctx.reply, ctx.jid, ctx.args));
reg(['wyr2', 'wouldyourather2'], async (ctx) => funCommands3.wouldYouRather2(ctx.reply));
reg(['wordscramble', 'acakkata'], async (ctx) => funCommands3.wordScramble(ctx.reply, ctx.jid));
reg(['jawabscramble'], async (ctx) => funCommands3.answerScramble(ctx.reply, ctx.jid, ctx.args));
reg(['riddle2', 'tekateki2'], async (ctx) => funCommands3.riddle2(ctx.reply, ctx.jid));
reg(['jawabriddle2'], async (ctx) => funCommands3.answerRiddle2(ctx.reply, ctx.jid, ctx.args));
reg(['dadjoke', 'lawakanbapak'], async (ctx) => funCommands3.dadJoke(ctx.reply));
reg(['konspirasi', 'conspiracyfun'], async (ctx) => funCommands3.conspiracyFun(ctx.reply));
reg(['kepribadianhariini', 'personalitytoday'], async (ctx) => funCommands3.personalityToday(ctx.reply));
reg(['rolldadu', 'multidice'], async (ctx) => funCommands3.rollMultiDice(ctx.reply, ctx.args));
reg(['guesshilo', 'tebakhilomulai'], async (ctx) => funCommands3.guessHigherLower(ctx.reply, ctx.jid));
reg(['tebakhilo'], async (ctx) => funCommands3.answerHigherLower(ctx.reply, ctx.jid, ctx.args));
reg(['pujianrandom2', 'randomcompliment2'], async (ctx) => funCommands3.randomCompliment2(ctx.reply, ctx.mentioned));
reg(['katahariini', 'wordoftheday'], async (ctx) => funCommands3.wordOfTheDay(ctx.reply));
reg(['pilihini', 'thisorthat'], async (ctx) => funCommands3.thisOrThat(ctx.reply));
reg(['magic8ball', 'tanyabola8'], async (ctx) => funCommands3.magic8ball(ctx.reply, ctx.args));
reg(['ratehariini', 'ratemyday'], async (ctx) => funCommands3.rateMyDay(ctx.reply));
reg(['angkakeberuntungan', 'luckynumber'], async (ctx) => funCommands3.luckyNumber(ctx.reply));
reg(['emojirandom', 'randomemoji'], async (ctx) => funCommands3.randomEmoji(ctx.reply));
reg(['pengagumrahasia', 'secretadmirer'], async (ctx) => funCommands3.secretAdmirer(ctx.reply));
reg(['afirmasihariini', 'dailyaffirmation'], async (ctx) => funCommands3.dailyAffirmation(ctx.reply));

// ── RPG BARU (rpgCommands5) ──────────────────────────────────────────────
reg(['gacha', 'undianitem'], async (ctx) => rpgCommands5.gacha(ctx.reply, ctx.sender));
reg(['expedition', 'ekspedisi'], async (ctx) => rpgCommands5.expedition(ctx.reply, ctx.sender));
reg(['klaimekspedisi', 'claimexpedition'], async (ctx) => rpgCommands5.claimExpedition(ctx.reply, ctx.sender));
reg(['titleku', 'mytitle', 'cektitle'], async (ctx) => rpgCommands5.checkTitle(ctx.reply, ctx.sender));
reg(['renamechar', 'gantinama'], async (ctx) => rpgCommands5.renameChar(ctx.reply, ctx.sender, ctx.args));
reg(['resetbuff', 'resetbuffs'], async (ctx) => rpgCommands5.resetBuffs(ctx.reply, ctx.sender));
reg(['statdetail', 'statlengkap'], async (ctx) => rpgCommands5.statDetail(ctx.reply, ctx.sender));

// ── TOOLS BARU (toolsCommands3) ──────────────────────────────────────────
reg(['cekpalindrom'], async (ctx) => toolsCommands3.checkPalindrome(ctx.reply, ctx.args));
reg(['cekcc'], async (ctx) => toolsCommands3.checkCreditCard(ctx.reply, ctx.args));
reg(['cekemail'], async (ctx) => toolsCommands3.checkEmail(ctx.reply, ctx.args));
reg(['ceknohp'], async (ctx) => toolsCommands3.checkPhoneNumber(ctx.reply, ctx.args));
reg(['caesarenkrip'], async (ctx) => toolsCommands3.caesarEncrypt(ctx.reply, ctx.args));
reg(['caesardekrip'], async (ctx) => toolsCommands3.caesarDecrypt(ctx.reply, ctx.args));
reg(['tomorse'], async (ctx) => toolsCommands3.toMorse(ctx.reply, ctx.args));
reg(['frommorse'], async (ctx) => toolsCommands3.fromMorse(ctx.reply, ctx.args));
reg(['bmidetail'], async (ctx) => toolsCommands3.bmiDetailed(ctx.reply, ctx.args));
reg(['umurdetail'], async (ctx) => toolsCommands3.calculateAge2(ctx.reply, ctx.args));
reg(['persenubah'], async (ctx) => toolsCommands3.percentageChange(ctx.reply, ctx.args));
reg(['diskon'], async (ctx) => toolsCommands3.discountCalc(ctx.reply, ctx.args));
reg(['splitbill', 'bagitagihan'], async (ctx) => toolsCommands3.splitBill(ctx.reply, ctx.args));
reg(['warnarandom', 'randomcolor'], async (ctx) => toolsCommands3.randomColor(ctx.reply));
reg(['tanggalrandom', 'randomdate'], async (ctx) => toolsCommands3.randomDate(ctx.reply, ctx.args));
reg(['textascii'], async (ctx) => toolsCommands3.textToAscii(ctx.reply, ctx.args));
reg(['asciitext'], async (ctx) => toolsCommands3.asciiToText(ctx.reply, ctx.args));
reg(['frekuensikata', 'wordfreq'], async (ctx) => toolsCommands3.wordFrequency(ctx.reply, ctx.args));
reg(['titlecase'], async (ctx) => toolsCommands3.titleCase(ctx.reply, ctx.args));
reg(['camelcase'], async (ctx) => toolsCommands3.camelCase(ctx.reply, ctx.args));
reg(['snakecase'], async (ctx) => toolsCommands3.snakeCase(ctx.reply, ctx.args));
reg(['kebabcase'], async (ctx) => toolsCommands3.kebabCase(ctx.reply, ctx.args));
reg(['hitungvokal'], async (ctx) => toolsCommands3.countVowels(ctx.reply, ctx.args));
reg(['hapusvokal'], async (ctx) => toolsCommands3.removeVowels(ctx.reply, ctx.args));
reg(['hitungkonsonan'], async (ctx) => toolsCommands3.countConsonants(ctx.reply, ctx.args));
reg(['ulangteks', 'repeattext'], async (ctx) => toolsCommands3.repeatText(ctx.reply, ctx.args));
reg(['suhu', 'tempconvert'], async (ctx) => toolsCommands3.tempConvert(ctx.reply, ctx.args));
reg(['hitungtip', 'tipcalc'], async (ctx) => toolsCommands3.tipCalc(ctx.reply, ctx.args));

// ── ADMIN GRUP BARU (adminCommands3) ─────────────────────────────────────
reg(['poll', 'buatpoll'], async (ctx) => adminCommands3.createPoll(ctx.reply, ctx.jid, ctx.args, ctx.isAdmin));
reg(['vote'], async (ctx) => adminCommands3.votePoll(ctx.reply, ctx.jid, ctx.sender, ctx.args));
reg(['hasilpoll', 'pollresult'], async (ctx) => adminCommands3.pollResult(ctx.reply, ctx.jid, ctx.args));
reg(['listpoll', 'daftarpoll'], async (ctx) => adminCommands3.listPolls(ctx.reply, ctx.jid));
reg(['addjadwal'], async (ctx) => adminCommands3.addSchedule(ctx.reply, ctx.jid, ctx.args, ctx.isAdmin));
reg(['listjadwal', 'jadwalgrup'], async (ctx) => adminCommands3.listSchedule(ctx.reply, ctx.jid));
reg(['deljadwal'], async (ctx) => adminCommands3.deleteSchedule(ctx.reply, ctx.jid, ctx.args, ctx.isAdmin));
reg(['lapor'], async (ctx) => adminCommands3.reportToAdmin(ctx.reply, ctx.jid, ctx.sender, ctx.args));
reg(['listlaporan', 'laporanmember'], async (ctx) => adminCommands3.listReports(ctx.reply, ctx.jid, ctx.isAdmin));
reg(['clearlaporan', 'bersihkanlaporan'], async (ctx) => adminCommands3.clearReports(ctx.reply, ctx.jid, ctx.isAdmin));
reg(['aktivitasgrup', 'groupactivity'], async (ctx) => adminCommands3.groupActivity(ctx.reply, ctx.jid));

// ─── SIDER — deteksi & kick member yang gak pernah/jarang chat ───────────
// ".sider" cuma menampilkan daftarnya (read-only). ".kicksider" langsung
// mengeluarkan semua yang terdeteksi — DESTRUKTIF, makanya tetap wajib
// admin (lihat isAdminCheck di dalam masing-masing handler).
// Threshold opsional: ".sider 7d" / ".kicksider 12h" dst (default 3 hari).
reg(['sider', 'cekrider', 'listsider'], async (ctx) =>
    adminCommands3.checkSider(ctx.sock, ctx.reply, ctx.jid, ctx.args, ctx.isAdmin));
reg(['kicksider', 'tendangrider'], async (ctx) =>
    adminCommands3.kickSider(ctx.sock, ctx.reply, ctx.msg, ctx.jid, ctx.args, ctx.isAdmin));

// ── BROADCAST (OWNER ONLY) ───────────────────────────────────────────────
reg(['broadcast', 'bc', 'broadcastgc'], async (ctx) => broadcastCommands.broadcastToGroups(ctx.sock, ctx.reply, ctx.args, ctx.isOwner));
reg(['broadcastuser', 'bcuser', 'broadcastpribadi'], async (ctx) => broadcastCommands.broadcastToUsers(ctx.sock, ctx.reply, ctx.args, ctx.isOwner));
reg(['listgrup', 'jumlahgrup', 'totalgrup'], async (ctx) => broadcastCommands.listGroupsCount(ctx.sock, ctx.reply, ctx.isOwner));

// ── JADIBOT ───────────────────────────────────────────────────────────────
reg(['jadibot', 'selfbot', 'pasangbot'], async (ctx) => jadibotCommands.startJadibot(ctx.reply, ctx.sender, ctx.args));
reg(['stopbot', 'matikanbot', 'berhentibot'], async (ctx) => jadibotCommands.stopJadibot(ctx.reply, ctx.sender, ctx.args, ctx.isOwner));
reg(['listjadibot', 'daftarjadibot'], async (ctx) => jadibotCommands.listJadibot(ctx.reply, ctx.isOwner));

// ─── MUSIK ────────────────────────────────────────────────────────
reg(['play', 'musik', 'music', 'lagu', 'ytmp3'], async (ctx) =>
    musicCommands.play(ctx.reply, ctx.sock, ctx.jid, ctx.msg, ctx.args));

// ─── DOWNLOAD SOSIAL MEDIA ──────────────────────────────────────────
// Sama seperti .play, dipakai bersama lib/ytdlpBinary.js (yt-dlp juga
// support Instagram & TikTok, jadi tidak ada dependency baru). Bisa
// dipakai dengan ".ig <link>" ATAU reply ke pesan yang isinya link.
reg(['ig', 'instagram', 'igdl', 'instagramdl'], async (ctx) =>
    socialDownloadCommands.downloadInstagram(ctx));
reg(['tiktok', 'tt', 'tiktokdl', 'ttdl'], async (ctx) =>
    socialDownloadCommands.downloadTiktok(ctx));
reg(['ytmp4', 'ytvideo', 'youtubemp4', 'ytv', 'ydl'], async (ctx) =>
    socialDownloadCommands.downloadYoutubeVideo(ctx));
reg(['twitter', 'twdl', 'twitterdl', 'xdl', 'xvideo'], async (ctx) =>
    socialDownloadCommands.downloadTwitter(ctx));
reg(['facebook', 'fbdl', 'fb', 'facebookdl', 'fbreels'], async (ctx) =>
    socialDownloadCommands.downloadFacebook(ctx));
reg(['scdl', 'soundcloud', 'soundclouddl'], async (ctx) =>
    socialDownloadCommands.downloadSoundcloud(ctx));
reg(['pin', 'pinterest', 'pindl', 'pinterestdl'], async (ctx) =>
    socialDownloadCommands.downloadPinterest(ctx));

// ─── KATEGORISASI OTOMATIS UNTUK .allmenu ──────────────────────────────────
// Daripada menebak kategori dari potongan nama command (rawan salah —
// contoh: kata pendek seperti 's' atau 'add' bisa nyangkut ke command lain
// yang tidak relevan), kita baca langsung source code handler-nya
// (handler.toString()) untuk tahu objek modul apa yang sebenarnya dipanggil
// di dalamnya (rpgCommands, adminCommands, funCommands, dst). Ini akurat
// karena bersumber dari kode aslinya, bukan tebakan kata kunci.
// PENTING: blok kategorisasi ini (termasuk pendaftaran command "allmenu" di
// bawah) HARUS berada SEBELUM baris `const routeMap = new Map(routes)`,
// supaya alias "allmenu" juga ikut masuk ke dalam routeMap. Kalau dipindah
// ke bawah routeMap, command tersebut akan terdaftar di array `routes` tapi
// tidak pernah masuk ke Map yang benar-benar dipakai untuk lookup saat user
// mengetik command — sehingga bot akan diam total tanpa error sama sekali
// (bug ini pernah terjadi pada versi sebelumnya, dan sudah diperbaiki).
const MODULE_TO_CATEGORY = {
    rpgCommands:        '⚔️ RPG',
    adminCommands:      '🛡️ Admin',
    funCommands:        '🎮 Fun',
    gojoCommands:       '🎮 Fun',
    toolsCommands:      '🛠️ Tools',
    textTools:          '🛠️ Tools',
    mathTools:          '🛠️ Tools',
    converterTools:     '🛠️ Tools',
    generatorTools:     '🛠️ Tools',
    infoTools:          '🛠️ Tools',
    validatorTools:     '🛠️ Tools',
    dateTools:          '🛠️ Tools',
    formatTools:        '🛠️ Tools',
    mediaCommands:      '🖼️ Media',
    bratCommands:       '🖼️ Media',
    jadibotCommands:    '🤖 Bot',
    broadcastCommands:  '🤖 Bot',
    musicCommands:           '🎵 Musik & Download',
    socialDownloadCommands:  '🎵 Musik & Download',
};
const CATEGORY_ORDER = ['⚔️ RPG', '🛡️ Admin', '🎮 Fun', '🛠️ Tools', '🖼️ Media', '🎵 Musik & Download', '👑 Jabatan', '🤖 Bot', '📦 Lainnya'];

// Command inline (arrow function langsung, bukan memanggil objek modul
// seperti rpgCommands.xxx()) tidak bisa dideteksi modulnya lewat
// categorizeByHandlerSource, sehingga sebelumnya semua jatuh ke "📦 Lainnya"
// — membuat kategori itu jadi tempat sampah campuran info bot, ping, dan
// command jabatan. Daftar berikut memetakan alias-alias spesifik tersebut
// ke kategori yang sebenarnya lebih tepat, dicek SEBELUM fallback umum.
const ALIAS_OVERRIDE_CATEGORY = {
    // Info umum bot → masuk kategori Bot
    ping: '🤖 Bot', cekping: '🤖 Bot', pingbot: '🤖 Bot',
    runtime: '🤖 Bot', uptime: '🤖 Bot', lamabotaktif: '🤖 Bot', botuptime: '🤖 Bot',
    whoami: '🤖 Bot', siapakahaku: '🤖 Bot', mynumber: '🤖 Bot', nomorku: '🤖 Bot',
    jam: '🤖 Bot', waktusekarang: '🤖 Bot', currenttime: '🤖 Bot', waktuserver: '🤖 Bot', servertime: '🤖 Bot',
    allmenu: '🤖 Bot', menu: '🤖 Bot', help: '🤖 Bot', start: '🤖 Bot',
    daftar: '🤖 Bot', register: '🤖 Bot',
    totalfitur: '🤖 Bot', totalfeature: '🤖 Bot', jumlahfitur: '🤖 Bot',
    pembayaran: '🤖 Bot', payment: '🤖 Bot', bayar: '🤖 Bot',
    sosmedowner: '🤖 Bot', sosmed: '🤖 Bot', socialmedia: '🤖 Bot',
    gojoai: '🤖 Bot',
    sider: '🛡️ Admin', cekrider: '🛡️ Admin', listsider: '🛡️ Admin',
    kicksider: '🛡️ Admin', tendangrider: '🛡️ Admin',
    // Jabatan Creator/Owner/Premium → kategori sendiri
    owner: '👑 Jabatan', creator: '👑 Jabatan', dev: '👑 Jabatan', developer: '👑 Jabatan',
    listowner: '👑 Jabatan', daftarowner: '👑 Jabatan', cekowner: '👑 Jabatan',
    addowner: '👑 Jabatan', delowner: '👑 Jabatan', removeowner: '👑 Jabatan',
    listprem: '👑 Jabatan', listpremium: '👑 Jabatan', daftarpremium: '👑 Jabatan',
    addprem: '👑 Jabatan', addpremium: '👑 Jabatan',
    delprem: '👑 Jabatan', delpremium: '👑 Jabatan', removepremium: '👑 Jabatan',
    cekjabatan: '👑 Jabatan', myrole: '👑 Jabatan', rolesaya: '👑 Jabatan', cekrole: '👑 Jabatan',
};

function categorizeByHandlerSource(handler) {
    const src = handler.toString();
    // Cari pola "namaModul.method(" atau "namaModulN.method(" di source handler
    const match = src.match(/\b([a-zA-Z]+(?:Commands|Tools))\d*\./);
    if (match && MODULE_TO_CATEGORY[match[1]]) return MODULE_TO_CATEGORY[match[1]];
    // Fallback: handler yang memanggil fungsi sendXxxMenu (bukan modul objek)
    if (/sendRpgMenu/.test(src)) return '⚔️ RPG';
    if (/sendAdminMenu/.test(src)) return '🛡️ Admin';
    if (/sendFunMenu/.test(src)) return '🎮 Fun';
    if (/sendToolsMenu/.test(src)) return '🛠️ Tools';
    if (/sendMediaMenu/.test(src)) return '🖼️ Media';
    if (/sendBotMenu|sendMainMenu/.test(src)) return '🤖 Bot';
    return '📦 Lainnya';
}

// (ALIAS_TO_CATEGORY dibangun di bawah, SETELAH semua reg() — termasuk
// reg(['allmenu']) di bawah ini — selesai dipanggil. Lihat penjelasan
// lengkap di dekat definisi routeMap.)

// FIX v3: .allmenu sekarang dikirim sebagai SATU pesan tunggal (bukan 9
// pesan terpisah seperti versi sebelumnya). Alasan: di lapangan ditemukan
// bahwa mengirim banyak pesan berurutan dalam waktu singkat ke koneksi
// WhatsApp yang sedang kurang stabil bisa menyebabkan kegagalan total tanpa
// error yang tertangkap sama sekali (tidak seperti .menu/.ping yang hanya
// kirim 1 pesan dan selalu berhasil). Pesan gabungan ini tetap di bawah
// limit aman (~11.000 karakter, jauh di bawah batas 60.000 karakter
// safeReplyText), dikelompokkan rapi per kategori dalam satu balasan.
reg(['allmenu'], async (ctx) => {
    const names = getAllCommandNames();
    const prefix = settings.prefix || '.';
    const creator = getCreatorInfo();
    const now = Date.now();

    const grouped = {};
    for (const name of names) {
        const cat = ALIAS_TO_CATEGORY.get(name) || '📦 Lainnya';
        (grouped[cat] ??= []).push(name);
    }

    // ── Header: info lengkap bertema Gojo, gaya bercabang (┌│└) ──────────
    const header =
`🥶 *${settings.botName}* ❄️ — Domain Penuh
_"Ini bukan cuma menu. Ini Unlimited Void — semua jurus, terlihat jelas."_

┌ 🕐 Waktu    : ${fmtTime(now)} WIB
│ 📅 Tanggal  : ${fmtDate(now)}
└ ⚡ Prefix   : \`${prefix}\`

┌ 👑 Creator  : ${creator.name}
│ 🌀 Status   : 🟢 Online & Siap Tarung
└ 📊 Total    : *${names.length}* command terdaftar

┌ 🛡️ Anti-GB        ✅   🛡️ Anti-Link      ✅
│ 🛡️ Anti-Shortlink ✅   🛡️ Anti-Spam      ✅
│ 🛡️ Anti-Toxic     ✅   🛡️ Anti-Flood     ✅
└ 📖 Auto-Read      ✅   ⏳ Cooldown       ✅

『 領域展開 — Semua Jurus Terungkap 』`;

    const sections = [header];

    // Setiap kategori ditampilkan dalam kotak bergaya: ╭─〔 emoji NAMA 〕─╮
    // diikuti ┣➤ command, ditutup ┗━━━. Untuk kategori yang isinya BANYAK
    // (RPG, Tools, dst — bisa 200+ command), list dipecah lagi per HURUF
    // AWAL (— A —, — B —, dst, seperti daftar kontak HP) supaya tidak jadi
    // satu tembok teks panjang yang malesin dibaca — orang bisa langsung
    // loncat ke huruf yang dia cari.
    const SPLIT_THRESHOLD = 20; // di atas ini, baru dipecah per huruf
    for (const cat of CATEGORY_ORDER) {
        const list = grouped[cat];
        if (!list || list.length === 0) continue;

        // Format satu baris command: .nama [tag]
        const fmt = n => {
            const tag = roleTag(n);
            return `┣➤ ${prefix}${n}${tag ? ' ' + tag : ''}`;
        };

        let body;
        if (list.length > SPLIT_THRESHOLD) {
            const sorted = [...list].sort();
            const byLetter = {};
            for (const name of sorted) {
                const letter = name[0].toUpperCase();
                (byLetter[letter] ??= []).push(name);
            }
            body = Object.keys(byLetter).sort().map(letter => {
                const lines = byLetter[letter].map(fmt);
                return `┃ ▸ *— ${letter} —*\n${lines.join('\n')}`;
            }).join('\n┃\n');
        } else {
            body = list.map(fmt).join('\n');
        }

        sections.push(
`╭─〔 *${cat}* 〕─╮ _(${list.length})_\n${body}\n┗━━━━━━━━━━━━━━━━⊱`
        );
    }

    sections.push(`\n— ✦☆✦ — *KETERANGAN*\n🌟 = CREATOR  |  Ⓞ = OWNER  |  Ⓐ = ADMIN  |  Ⓟ = PREMIUM\n_Tanpa simbol = bisa dipakai semua user (free)_\n\n💡 Ketik *${prefix}menu* untuk tampilan ringkas.\n「 _Infinity has no limit — and neither does this list._ 」`);

    const text = sections.join('\n\n');
    // Kirim dengan thumbnail Gojo Satoru, fallback ke teks biasa jika gagal
    if (settings.thumbnailUrl) {
        try {
            await ctx.sock.sendMessage(ctx.jid, {
                image: { url: settings.thumbnailUrl },
                caption: text
            }, { quoted: ctx.msg });
            return;
        } catch { /* fallback below */ }
    }
    await ctx.reply(text);
});

const routeMap = new Map(routes);

// ─── ROLE TAG MAP ─────────────────────────────────────────────────────────
// Pemetaan alias command → tag jabatan yang diperlukan.
// 🌟 = Creator only  |  Ⓞ = Owner  |  Ⓐ = Admin grup  |  Ⓟ = Premium
// Tidak ada tag = Free (semua user bisa pakai)
const ROLE_TAG = {
    // Creator only
    addcreator: '🌟', removecreator: '🌟', delcreator: '🌟',

    // Owner / Creator
    addowner: 'Ⓞ', delowner: 'Ⓞ', removeowner: 'Ⓞ',
    addprem: 'Ⓞ', addpremium: 'Ⓞ', delprem: 'Ⓞ', delpremium: 'Ⓞ', removepremium: 'Ⓞ',
    broadcast: 'Ⓞ', broadcastgc: 'Ⓞ', bc: 'Ⓞ',
    broadcastuser: 'Ⓞ', bcuser: 'Ⓞ', broadcastpribadi: 'Ⓞ',
    listgrup: 'Ⓞ', jumlahgrup: 'Ⓞ', totalgrup: 'Ⓞ',
    listjadibot: 'Ⓞ', daftarjadibot: 'Ⓞ',
    addgold: 'Ⓞ', tambahgold: 'Ⓞ', givegold: 'Ⓞ',
    addlimit: 'Ⓞ', tambablimit: 'Ⓞ',

    // Admin grup
    kick: 'Ⓐ', keluarkan: 'Ⓐ', tendang: 'Ⓐ',
    ryoiken: 'Ⓐ', ryoikitenkai: 'Ⓐ', domainexpansion: 'Ⓐ', tenkai: 'Ⓐ',
    promote: 'Ⓐ', jadikanadmin: 'Ⓐ', naikkan: 'Ⓐ',
    demote: 'Ⓐ', turunkan: 'Ⓐ', copotadmin: 'Ⓐ',
    add: 'Ⓐ', tambahmember: 'Ⓐ', invite: 'Ⓐ',
    warn: 'Ⓐ', peringatan: 'Ⓐ', beriwarn: 'Ⓐ',
    unwarn: 'Ⓐ', hapuswarn: 'Ⓐ',
    warnlimit: 'Ⓐ', limitwarn: 'Ⓐ', setwarnlimit: 'Ⓐ',
    mute: 'Ⓐ', bisukan: 'Ⓐ',
    unmute: 'Ⓐ', bukabisu: 'Ⓐ',
    lockgroup: 'Ⓐ', kuncigrup: 'Ⓐ', closegroup: 'Ⓐ',
    unlockgroup: 'Ⓐ', bukagrup: 'Ⓐ', opengroup: 'Ⓐ',
    setname: 'Ⓐ', gantinamagrup: 'Ⓐ', namagrup: 'Ⓐ',
    setdesc: 'Ⓐ', gantidesk: 'Ⓐ', deskripsigrup: 'Ⓐ',
    link: 'Ⓐ', linkgrup: 'Ⓐ', invitelink: 'Ⓐ', getlink: 'Ⓐ',
    revoke: 'Ⓐ', resetlink: 'Ⓐ', revokelink: 'Ⓐ',
    leave: 'Ⓐ', keluargrup: 'Ⓐ', botkeluar: 'Ⓐ',
    hidetag: 'Ⓐ', htag: 'Ⓐ', tagsemua: 'Ⓐ',
    tagall: 'Ⓐ', mentionall: 'Ⓐ', tagsemuamember: 'Ⓐ',
    antilink: 'Ⓐ', antispam: 'Ⓐ', antiflood: 'Ⓐ',
    antitoxic: 'Ⓐ', antibot: 'Ⓐ', antisara: 'Ⓐ', antigb: 'Ⓐ',
    setwelcome: 'Ⓐ', setfarewell: 'Ⓐ', slowmode: 'Ⓐ',
    locklink: 'Ⓐ', locksticker: 'Ⓐ', lockvideo: 'Ⓐ', lockgambar: 'Ⓐ',
    poll: 'Ⓐ', buatpoll: 'Ⓐ',
    addjadwal: 'Ⓐ', deljadwal: 'Ⓐ',
    listlaporan: 'Ⓐ', laporanmember: 'Ⓐ',
    clearlaporan: 'Ⓐ', bersihkanlaporan: 'Ⓐ',
    sider: 'Ⓐ', cekrider: 'Ⓐ', listsider: 'Ⓐ',
    kicksider: 'Ⓐ', tendangrider: 'Ⓐ',
};

function roleTag(alias) {
    return ROLE_TAG[alias] || '';
}

// Bangun mapping alias -> kategori SETELAH semua reg() (termasuk
// reg(['allmenu'])) selesai dipanggil — supaya allmenu sendiri juga
// terklasifikasi dengan benar, bukan jatuh ke fallback "📦 Lainnya".
// (Sebelumnya ini dibangun SEBELUM reg(['allmenu']) dipanggil, sehingga
// alias "allmenu" belum ada di array `routes` saat iterasi ini berjalan
// — bug yang sama persis pernah terjadi pada routeMap itu sendiri.)
const ALIAS_TO_CATEGORY = new Map();
for (const [alias, handler] of routes) {
    if (!ALIAS_TO_CATEGORY.has(alias)) {
        const cat = ALIAS_OVERRIDE_CATEGORY[alias] || categorizeByHandlerSource(handler);
        ALIAS_TO_CATEGORY.set(alias, cat);
    }
}

export function getRegisteredCommandCount() {
    // Tidak menghitung command rahasia agar angka "jumlah fitur" yang
    // ditampilkan ke user tidak membocorkan keberadaan fitur tersembunyi.
    return [...routeMap.keys()].filter(name => !HIDDEN_COMMANDS.has(name)).length;
}

export function getAllCommandNames() {
    return [...routeMap.keys()].filter(name => !HIDDEN_COMMANDS.has(name)).sort();
}

// ── Reaksi emoji sebagai indikator status command ───────────────────────
// ⏳ = sedang diproses, ✅ = berhasil, ❌ = gagal/error. Reaksi dikirim ke
// pesan ASLI dari user (msg.key), jadi kelihatan langsung di pesan yang
// dia ketik sendiri — tidak perlu baca teks balasan bot buat tahu status.
// Dibungkus try/catch supaya reaksi yang gagal terkirim (jaringan lagi
// bermasalah, dsb) tidak ikut menggagalkan command itu sendiri.
async function reactTo(sock, jid, msgKey, emoji) {
    try { await sock.sendMessage(jid, { react: { text: emoji, key: msgKey } }); } catch {}
}

export async function handleCommand(sock, msg, jid, sender, command, args, isGroup, body, precomputedIsAdmin) {
    let isAdmin = false;
    if (typeof precomputedIsAdmin === 'boolean') {
        isAdmin = precomputedIsAdmin;
    } else if (isGroup) {
        try {
            // FIX: dibungkus withTimeout — lihat penjelasan lengkap di
            // messagePipeline.js mengenai risiko groupMetadata() hang tanpa
            // batas waktu pada koneksi yang sedang rate-limited.
            const metadata = await withTimeout(sock.groupMetadata(jid), 15_000, 'groupMetadata(handleCommand)');
            // FIX @lid: p.id di groupMetadata bisa @lid sementara sender @s.whatsapp.net
            const participant = metadata.participants.find(p => {
                if (p.id === sender) return true;
                if (p.id.includes('@lid')) { const r = recallRealJid(p.id); if (r && r === sender) return true; }
                if (sender.includes('@lid')) { const r = recallRealJid(sender); if (r && r === p.id) return true; }
                return false;
            });
            isAdmin = participant?.admin === 'admin' || participant?.admin === 'superadmin';
        } catch {
            isAdmin = false;
        }
    }

    // Hirarki jabatan: Creator > Owner > Premium > User biasa.
    // isOwner tetap dipertahankan sebagai nama field di ctx (kompatibel
    // dengan command lama yang sudah memakai ctx.isOwner), tapi sekarang
    // sumber kebenarannya dari roles.js (mendukung banyak Owner dinamis,
    // bukan cuma satu nomor statis dari settings.ownerNumber).
    // FIX: dibungkus try/catch — sebelumnya kalau salah satu dari ketiga
    // fungsi ini melempar error (misal db.js gagal baca/tulis file data),
    // errornya akan keluar dari handleCommand() TANPA tertangkap try/catch
    // apapun (karena posisinya di luar blok try di bawah), sehingga
    // SEMUA command gagal total tanpa balasan apapun ke user — walau log
    // "⚡ ... → .command" tetap muncul di console karena itu dicatat
    // sebelum titik ini. Sekarang errornya hanya membuat ctx.isCreator/
    // isOwner/isPremium default ke false (paling aman), bukan menggagalkan
    // seluruh proses command.
    let isCreatorFlag = false, isOwnerFlag = false, isPremiumFlag = false;
    try {
        isCreatorFlag = isCreator(sender);
        isOwnerFlag   = isOwner(sender);
        isPremiumFlag = isPremium(sender);
    } catch (err) {
        log.error(`Gagal cek jabatan untuk ${sender}: ${err.message}`);
    }
    const reply = (text) => replyWithThumb(sock, jid, text, msg);
    const mentioned = getMentioned(msg);

    const handler = routeMap.get(command);
    if (!handler) {
        log.error(`Command "${command}" TIDAK DITEMUKAN di routeMap (total ${routeMap.size} command terdaftar).`);
        return;
    }

    // ── Sewa Mode check ────────────────────────────────────────────────────
    // Kalau sewaMode ON dan ini grup → hanya grup bersewa yang bisa jalan.
    // Owner/Creator selalu bypass. Command info-sewa (ceksewa, hargasewa) juga bypass.
    const SEWA_BYPASS_CMDS = new Set(['ceksewa','infosewa','statussewa','hargasewa','pricesewa','infoharga','menu','help','start']);
    if (isGroup && isSewaMode() && !isOwnerFlag && !isCreatorFlag && !SEWA_BYPASS_CMDS.has(command)) {
        if (!isSewaActive(jid)) {
            return replyWithThumb(sock, jid,
                `⏳ *Bot Belum Disewa*\n\n` +
                `Grup ini belum memiliki sewa bot aktif.\n` +
                `Ketik \`${settings.prefix}hargasewa\` untuk info harga dan cara sewa.`,
                msg
            );
        }
    }

    // Track command usage analytics
    try { trackCommand(command); } catch {}

    const ctx = {
        sock, msg, jid, sender, args, isGroup, body, reply, isAdmin,
        isOwner: isOwnerFlag,
        isCreator: isCreatorFlag,
        isPremium: isPremiumFlag,
        mentioned,
    };

    // FIX: reaksi ⏳ sekarang dikirim lebih awal, di messagePipeline.js
    // (sebelum autoTyping) — supaya muncul INSTAN saat command diterima,
    // bukan baru muncul setelah delay "mengetik..." 3-4 detik. Di sini
    // tinggal reaksi hasil akhirnya (✅ / ❌) setelah handler selesai.
    try {
        const longTimeoutCommands = [
            'play', 'musik', 'music', 'lagu', 'ytmp3',
            'ig', 'instagram', 'igdl', 'instagramdl',
            'tiktok', 'tt', 'tiktokdl', 'ttdl',
            'iqc', 'iphonequote', 'iphoneqc', 'imessagequote',
        ];
        const timeoutMs = longTimeoutCommands.includes(command) ? 180_000 : 60_000;
        await withTimeout(handler(ctx), timeoutMs, `command "${command}"`);
        await reactTo(sock, jid, msg.key, '✅');
    } catch (err) {
        log.error(`Command "${command}": ${err.message}`);
        try { await reply('⚠️ Terjadi kesalahan saat menjalankan command ini.'); } catch {}
        await reactTo(sock, jid, msg.key, '❌');
    }
}

export { checkMute, isGroupLocked };
