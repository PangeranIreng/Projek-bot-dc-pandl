// ═══════════════════════════════════════════════════════════════════
//  BRATCOMMANDS.JS — Brat, IQC
//
//  CATATAN (2026-07-07): variant brat dipangkas jadi cuma 3 command —
//  .brat (default), .bratwhite, .bratgreen — sesuai permintaan. Semua
//  variant tematik (brathd/bratanime/bratpatrick/bratsquidward/bratgojo/
//  bratvermeil), variant VIDEO (bratvid/bratvid2/bratgojovid/
//  bratvermeilvid), dan menu picker interaktifnya (bratMenu) sengaja
//  dihapus. Fungsi generator video & helper terkait (fetchBratVidClip,
//  BRATVID_MAX_WORDS) ikut dihapus karena sudah tidak dipakai sama
//  sekali. `iqc` TIDAK disentuh — itu fitur terpisah, bukan variant brat.
// ═══════════════════════════════════════════════════════════════════

import settings from '../setting.js';
import { imageToWebpSticker } from '../lib/videoGen.js';

const PREFIX = settings.prefix || '.';
const FAA_BASE = 'https://api-faa.my.id'; // masih dipakai iqc() di bawah — belum diganti, di luar laporan bug ini

// FIX (2026-07-07): api-faa.my.id (bekas base URL brat) sudah mati/error —
// diganti ke endpoint brat.siputzx.my.id (masih aktif).
const SIPUTZX_BASE = 'https://brat.siputzx.my.id';

// ── 3 variant gambar yang tersisa: brat (default) / bratgreen / bratwhite ──
// Semua di-render lewat endpoint yang sama (SIPUTZX_BASE + /image) —
// bedanya cuma parameter warna latar/teks.
const IMAGE_VARIANT_COLORS = {
    brat:       { bg: 'ffffff', color: '000000' }, // default — gaya sticker brat original
    bratgreen:  { bg: '8ace00', color: '000000' }, // hijau asli album "Brat"
    bratwhite:  { bg: 'ffffff', color: '000000' },
};

// ── Fetch helper ──────────────────────────────────────────────────
async function fetchBuf(url, timeoutMs = 30_000) {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), timeoutMs);
    try {
        const res = await fetch(url, {
            signal: ctrl.signal,
            headers: {
                // Beberapa provider REST API gratis (termasuk kemungkinan
                // api-faa.my.id) menolak request tanpa User-Agent yang
                // wajar dengan 403. fetch() Node tidak mengirim UA sama
                // sekali secara default, jadi kita set manual di sini.
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
                'Accept': '*/*',
            },
        });
        if (!res.ok) {
            // Sertakan potongan body respons (kalau ada) supaya pesan error
            // yang tampil ke user tidak cuma "HTTP 403" polos, tapi juga
            // alasan aslinya kalau providernya mengirim JSON/teks penjelasan
            // (mis. "apikey wajib diisi" atau "rate limit tercapai").
            let detail = '';
            try {
                detail = (await res.text()).replace(/\s+/g, ' ').trim().slice(0, 150);
            } catch { /* body tidak bisa dibaca, abaikan */ }
            throw new Error(`HTTP ${res.status}${detail ? ` — ${detail}` : ''}`);
        }
        const ab = await res.arrayBuffer();
        return Buffer.from(ab);
    } finally {
        clearTimeout(timer);
    }
}

// ── Generator gambar brat (.brat / .bratgreen / .bratwhite) ────────
export async function bratGenerate(ctx, variant = 'brat') {
    const { args, reply } = ctx;
    const text = args?.join(' ') || '';
    if (!text) {
        return reply(
            `📌 Cara pakai: \`${PREFIX}${variant} <teks>\`\n` +
            `Contoh: \`${PREFIX}${variant} selow lah\``
        );
    }

    return bratGenerateImage(ctx, variant, text);
}

// ── Variant GAMBAR: brat (default) / bratgreen / bratwhite ─────────
async function bratGenerateImage(ctx, variant, text) {
    const { sock, jid, msg, reply } = ctx;
    const { bg, color } = IMAGE_VARIANT_COLORS[variant] || IMAGE_VARIANT_COLORS.brat;
    const url = `${SIPUTZX_BASE}/image?text=${encodeURIComponent(text)}&background=%23${bg}&color=%23${color}&emojiStyle=apple`;

    await reply('⏳ Membuat brat gambar...');

    try {
        const raw = await fetchBuf(url);
        const sticker = await imageToWebpSticker(raw);
        await sock.sendMessage(jid, { sticker }, { quoted: msg });
    } catch (err) {
        await reply(`❌ Gagal generate brat: ${err.message}\n\nCoba lagi beberapa saat.`);
    }
}

// ── IQC — iPhone Quote Creator ─────────────────────────────────────
export async function iqc(ctx) {
    const { sock, jid, msg, args, reply } = ctx;
    const text = args?.join(' ') || '';

    if (!text) {
        return reply(
            `📱 *iPhone Quote Creator*\n\n` +
            `Buat gambar quote bergaya iMessage/iPhone.\n\n` +
            `📌 Cara: \`${PREFIX}iqc <teks>\`\n` +
            `Contoh: \`${PREFIX}iqc Gojo terkuat sejagad raya\``
        );
    }

    await reply('⏳ Membuat iPhone quote...');

    try {
        const url = `${FAA_BASE}/faa/iqc?prompt=${encodeURIComponent(text)}`;
        const buf = await fetchBuf(url);

        await sock.sendMessage(jid, {
            image: buf,
            caption:
                `📱 *iPhone Quote Creator*\n\n` +
                `_"${text}"_\n\n` +
                `> Dibuat dengan ${PREFIX}iqc`,
        }, { quoted: msg });
    } catch (err) {
        await reply(`❌ Gagal membuat IQC: ${err.message}\n\nCoba lagi beberapa saat.`);
    }
}
