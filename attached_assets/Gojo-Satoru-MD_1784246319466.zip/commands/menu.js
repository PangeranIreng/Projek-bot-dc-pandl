import settings from '../setting.js';
import { fmtDate, fmtTime, fmtDuration } from '../lib/utils.js';
import { getChar } from '../lib/rpgEngine.js';
import { expNeeded } from '../lib/rpgData.js';
import { log } from '../lib/logger.js';
import { markMenuPending } from '../lib/menuShortcut.js';

const P   = settings.prefix   || '.';
const BOT = settings.botName  || 'Gojo Satoru MD';
const TAG = settings.botTagline || '❄️ Infinity Edition';

// ─── MENU UTAMA (RINGKAS) ─────────────────────────────────────────
// Sengaja dibuat singkat — info lengkap (proteksi aktif & daftar semua
// command) dipindahkan ke .allmenu, supaya .menu cepat dibaca sekilas.
// Struktur info (Nama/Status/Uptime/Respon/Versi/Mode/Prefix) terinspirasi
// dari format menu bot lain yang dicontohkan user, disesuaikan ke identitas
// Gojo Satoru MD.
export async function sendMainMenu(reply, sender, sock, jid, msg, opts = {}) {
    const now     = Date.now();
    const jam     = fmtTime(now);
    const tanggal = fmtDate(now);
    const { isOwner = false, isPremium = false, pushName = null, botStartTime = now } = opts;

    let latensi = 0;
    if (sock && jid) {
        const t0 = Date.now();
        try { await sock.sendPresenceUpdate('composing', jid); } catch { /* abaikan */ }
        latensi = Date.now() - t0;
    }

    const statusLabel = isOwner ? 'Pemilik Bot 👑' : isPremium ? 'Premium 💎' : 'Free User 🌿';
    const namaTampil  = pushName || (sender ? sender.split('@')[0] : 'Kakak');

    const char = sender ? getChar(sender) : null;
    const userLines = char
        ? `┌ 🗡️ Kelas  : ${char.class}\n│ ✨ Level  : ${char.level} _(exp ${char.exp}/${expNeeded(char.level)})_\n└ 💰 Gold   : ${char.gold}`
        : `└ 💡 Ketik *${P}rpg* buat mulai petualangan`;

    const menuText =
`╭━━━〔 🌊 *${BOT.toUpperCase()}* 🌊 〕━━━⬣
┃ ⟤ 𝙉𝙖𝙢𝙖      : ${namaTampil}
┃ ⟤ 𝙎𝙩𝙖𝙩𝙪𝙨    : ${statusLabel}
┃ ⟤ 𝙐𝙥𝙩𝙞𝙢𝙚    : ${fmtDuration(now - botStartTime)}
┃ ⟤ 𝙍𝙚𝙨𝙥𝙤𝙣    : ${latensi.toFixed(2)} ms
┃ ⟤ 𝙑𝙚𝙧𝙨𝙞     : v${settings.botVersion || '3.0.0'}
┃ ⟤ 𝙈𝙤𝙙𝙚      : ${settings.public !== false ? 'Public' : 'Private'}
┃ ⟤ 𝙋𝙧𝙚𝙛𝙞𝙭    : ${P}
╰━━━━━━━━━━━━━━━━━━━━⬣

${userLines}

╭━━━〔 💭 𝑵𝑶𝑻𝑬 〕━━━⬣
┃ _"Fitur bot ini mungkin tak sebanyak bot lain,_
┃ _tapi bot lain belum tentu rajin update & fix error 😝"_
╰━━━━━━━━━━━━━━━━━━━━⬣

╭━━━〔 📖 𝑲𝑬𝑻𝑬𝑹𝑨𝑵𝑮𝑨𝑵 〕━━━⬣
┃ ⟤ 🌟 = 𝑪𝑹𝑬𝑨𝑻𝑶𝑹
┃ ⟤ Ⓞ = 𝑶𝑾𝑵𝑬𝑹
┃ ⟤ Ⓐ = 𝑨𝑫𝑴𝑰𝑵
┃ ⟤ Ⓟ = 𝑷𝑹𝑬𝑴𝑰𝑼𝑴
┃ ⟤ _Tanpa simbol = Free (semua bisa pakai)_
╰━━━━━━━━━━━━━━━━━━━━⬣`;
    // SATU pesan gabungan (bukan 2 pesan terpisah lagi): thumbnail jadi header
    // interactiveMessage, menuText (info bot + KETERANGAN) jadi body, tombol
    // tetap nativeFlowMessage seperti sebelumnya. Sebelumnya ini 2 pesan
    // (gambar+caption dulu, baru interactiveMessage menyusul) makanya di WA
    // muncul sebagai 2 bubble kepisah — sekarang cukup 1 relayMessage.
    // Pattern yang sudah terbukti stabil lewat trial-and-error:
    // 1. Bungkus dalam viewOnceMessage.message
    // 2. contextInfo (forwardedNewsletterMessageInfo) taruh DALAM interactiveMessage
    // 3. nativeFlowMessage sebagai plain object (bukan proto.create)
    // 4. relayMessage + additionalNodes biz/native_flow
    if (sock && jid) {
        try {
            const { generateWAMessageFromContent, prepareWAMessageMedia } = await import('@whiskeysockets/baileys');

            // Siapkan thumbnail sebagai media header. Kalau gagal (URL
            // bermasalah dll), lanjut TANPA gambar di header — jangan sampai
            // gara-gara 1 thumbnail, seluruh menu gagal terkirim.
            let headerMedia = {};
            if (settings.thumbnailUrl) {
                try {
                    headerMedia = await prepareWAMessageMedia(
                        { image: { url: settings.thumbnailUrl } },
                        { upload: sock.waUploadToServer }
                    );
                } catch (err) {
                    log?.warn?.(`[menu] gagal siapkan thumbnail header: ${err.message}`);
                }
            }

            const rows = [
                { title: '⚔️ Menu RPG',    description: 'Petualangan, dungeon, gacha, PvP & craft',    id: `${P}menurpg`   },
                { title: '🛡️ Menu Admin',  description: 'Manajemen grup, proteksi & warn sistem',      id: `${P}menuadmin` },
                { title: '🎮 Menu Fun',     description: 'Game, trivia, roast, tarot & hiburan',         id: `${P}menufun`   },
                { title: '🛠️ Menu Tools',  description: 'Kalkulator, konversi, enkripsi & utilitas',  id: `${P}menutools` },
                { title: '🖼️ Menu Media',  description: 'Sticker, download TikTok/IG & foto profil',  id: `${P}menumedia` },
                { title: '🤖 Menu Bot',     description: 'Owner control, broadcast & jadibot',           id: `${P}menubot`   },
                { title: '📜 All Menu',     description: 'Lihat SEMUA command lengkap sekaligus',        id: `${P}allmenu`   }
            ];

            const waMsg = generateWAMessageFromContent(jid, {
                messageContextInfo: {
                    deviceListMetadata: {},
                    deviceListMetadataVersion: 2
                },
                interactiveMessage: {
                    header: {
                        title: '〔 領域展開 〕 Pilih Domain-mu',
                        hasMediaAttachment: !!headerMedia.imageMessage,
                        ...headerMedia
                    },
                    body: {
                        text: `${menuText}\n\nKetuk tombol di bawah untuk memilih kategori command 👇`
                    },
                    footer: {
                        text: `© ${BOT} | Gojo Satoru Official`
                    },
                    contextInfo: {
                        isForwarded: true,
                        forwardingScore: 999,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: '120363428989828271@newsletter',
                            newsletterName: 'Gojo Satoru Official',
                            serverMessageId: 1
                        }
                    },
                    nativeFlowMessage: {
                        buttons: [{
                            name: 'single_select',
                            buttonParamsJson: JSON.stringify({
                                title: '📋 Buka Daftar Menu',
                                sections: [{ title: '📚 KATEGORI MENU', rows }]
                            })
                        }]
                    }
                }
            }, { quoted: msg, userJid: sock.user?.jid });

            await sock.relayMessage(jid, waMsg.message, {
                messageId: waMsg.key.id,
                additionalNodes: [{
                    tag: 'biz',
                    attrs: {},
                    content: [{
                        tag: 'interactive',
                        attrs: { type: 'native_flow', v: '1' },
                        content: [{ tag: 'native_flow', attrs: { v: '9', name: 'mixed' } }]
                    }]
                }]
            });
        } catch (err) {
            log?.warn?.(`[menu] tombol interaktif gagal: ${err.message}`);
            // Fallback: SATU pesan teks polos (info bot + KETERANGAN + shortcut
            // angka digabung) — walau interaktif gagal total, user tetap cuma
            // terima 1 pesan, bukan 2.
            markMenuPending(sender);
            await reply(
`${menuText}

『 領域展開 — Pilih Domain-mu 』
_Balas angka 1-7 atau ketik command-nya:_

*1* — ⚔️ Menu RPG
*2* — 🛡️ Menu Admin
*3* — 🎮 Menu Fun
*4* — 🛠️ Menu Tools
*5* — 🖼️ Menu Media
*6* — 🤖 Menu Bot
*7* — 📜 All Menu`
            );
        }
    }
}

export async function sendRpgMenu(reply) {
    await reply(
`╔══════════════════════════════════════╗
║   ⚔️  *MENU RPG — DUNIA PETUALANGAN*
╚══════════════════════════════════════╝

╭─「 👤 *KARAKTER* 」
│ ${P}rpg          — Buat karakter baru
│ ${P}profil        — Lihat statistik karakter
│ ${P}class [nama]  — Ganti kelas (Warrior/Mage/Archer/Rogue)
│ ${P}inventory     — Buka tas / backpack
│ ${P}equip [item]  — Pakai senjata / armor
│ ${P}use [item]    — Gunakan potion / konsumabel
│ ${P}istirahat     — Pulihkan HP (cooldown 5m)
│ ${P}statdetail    — Statistik lengkap karakter
╰──────────────────────────────

╭─「 ⚔️ *PERTARUNGAN* 」
│ ${P}hunt           — Berburu monster (CD 45d)
│ ${P}lawan @tag     — Duel PvP dengan member
│ ${P}boss [nama]    — Raid boss kuat
│ ${P}dungeon [nama] — Masuk dungeon
│ ${P}bossinfo       — Daftar semua boss
│ ${P}dungeoninfo    — Daftar semua dungeon
╰──────────────────────────────

╭─「 💰 *EKONOMI & TOKO* 」
│ ${P}toko           — Buka toko item
│ ${P}beli [item]    — Beli item dari toko
│ ${P}jual [item]    — Jual item ke toko
│ ${P}daily          — Klaim reward harian (CD 24j)
│ ${P}kerja [job]    — Kerja cari gold (CD 20m)
│ ${P}joblist        — Daftar pekerjaan tersedia
│ ${P}nabung [jml]   — Simpan gold ke bank
│ ${P}tarik [jml]    — Tarik gold dari bank
│ ${P}transfer @tag  — Kirim gold ke player lain
│ ${P}rob @tag       — Curi gold player lain 🗡️
╰──────────────────────────────

╭─「 ✨ *GACHA & EKSPEDISI* 」
│ ${P}gacha          — Undian item acak (butuh tiket)
│ ${P}expedition     — Mulai ekspedisi (CD 6j)
│ ${P}klaimekspedisi — Ambil hasil ekspedisi
╰──────────────────────────────

╭─「 🐾 *PET SYSTEM* 」
│ ${P}petshop        — Toko peliharaan
│ ${P}buypet [nama]  — Beli pet baru
│ ${P}petinfo        — Info pet yang dimiliki
│ ${P}setpet [nama]  — Aktifkan pet tertentu
╰──────────────────────────────

╭─「 📜 *QUEST & ACHIEVEMENT* 」
│ ${P}quest          — Daftar quest aktif
│ ${P}questclaim [n] — Klaim reward quest selesai
│ ${P}achievement    — Lihat pencapaian
╰──────────────────────────────

╭─「 🏆 *RANKING & SOSIAL* 」
│ ${P}ranking        — Top 10 player
│ ${P}leaderboard    — Papan skor
│ ${P}marry @tag     — Menikah dengan player
│ ${P}divorce        — Cerai 💔
╰──────────────────────────────

╭─「 ⚒️ *CRAFTING & UPGRADE* 」
│ ${P}mine           — Tambang batu & ore (CD 30m)
│ ${P}fish           — Pancing ikan (CD 20m)
│ ${P}craft [item]   — Buat item baru
│ ${P}refine [item]  — Tingkatkan kualitas item
│ ${P}train [stat]   — Latihan tingkatkan stat
│ ${P}prestige       — Prestige (reset untuk bonus!)
╰──────────────────────────────

╭─「 🎰 *GAMBLING* 」
│ ${P}gamble [jml]   — Taruhan gold (CD 10m)
│ ${P}lottery        — Beli tiket lotre (CD 1j)
╰──────────────────────────────`
    );
}

// ─── MENU ADMIN ───────────────────────────────────────────────────
export async function sendAdminMenu(reply) {
    await reply(
`╔══════════════════════════════════════╗
║   🛡️  *MENU ADMIN & MANAJEMEN GRUP*
╚══════════════════════════════════════╝

╭─「 👥 *MANAJEMEN MEMBER* 」
│ ${P}kick @tag        — Keluarkan member
│ ${P}promote @tag     — Jadikan admin
│ ${P}demote @tag      — Cabut jabatan admin
│ ${P}add 628xxx       — Tambah member baru
│ ${P}listadmin        — Daftar admin grup
│ ${P}membercount      — Jumlah total member
╰──────────────────────────────

╭─「 👑 *JABATAN BOT* 」
│ ${P}cekjabatan [@tag] — Cek jabatan (Creator/Owner/Premium)
│ ${P}addowner @tag    — Angkat Owner _(Creator only)_
│ ${P}delowner @tag    — Cabut Owner _(Creator only)_
│ ${P}listowner        — Daftar Creator & Owner
│ ${P}addprem @tag     — Angkat Premium _(Owner only)_
│ ${P}delprem @tag     — Cabut Premium _(Owner only)_
│ ${P}listprem         — Daftar user Premium
│
│ _Bisa juga diatur permanen lewat_
│ _\`ownerNumbers\` / \`premiumNumbers\`_
│ _di setting.js (butuh restart)._
╰──────────────────────────────

╭─「 ⚠️ *SISTEM WARN* 」
│ ${P}warn @tag        — Beri peringatan
│ ${P}unwarn @tag      — Hapus peringatan
│ ${P}checkwarn @tag   — Cek jumlah warn
│ ${P}warnlimit [n]    — Atur batas warn (default 3)
╰──────────────────────────────

╭─「 🔇 *MUTE & KUNCI GRUP* 」
│ ${P}mute [durasi]    — Mute semua member
│ ${P}unmute           — Unmute grup
│ ${P}mutestatus       — Cek status mute
│ ${P}lockgroup        — Kunci grup (hanya admin bisa chat)
│ ${P}unlockgroup      — Buka kunci grup
│ ${P}slowmode [detik] — Aktifkan slow mode
│ ${P}lockmedia on/off — Kunci pengiriman media
│ ${P}lockstiker on/off— Kunci pengiriman stiker
╰──────────────────────────────

╭─「 ⚙️ *PENGATURAN GRUP* 」
│ ${P}groupinfo        — Info lengkap grup
│ ${P}setname [nama]   — Ubah nama grup
│ ${P}setdesc [teks]   — Ubah deskripsi grup
│ ${P}link             — Dapatkan link undangan
│ ${P}revoke           — Reset link undangan
│ ${P}leave            — Bot keluar dari grup
│ ${P}hidetag [teks]   — Mention semua (tersembunyi)
│ ${P}tagall [teks]    — Mention semua member
╰──────────────────────────────

╭─「 👋 *WELCOME & FAREWELL* 」
│ ${P}welcome on/off   — Toggle pesan sambutan
│ ${P}setwelcome [teks]— Atur teks sambutan
│ ${P}farewell on/off  — Toggle pesan perpisahan
│ ${P}setfarewell [txt]— Atur teks perpisahan
│   _Variabel: {name} {group} {num}_
╰──────────────────────────────

╭─「 🛡️ *PROTEKSI* 」
│ ${P}antigb on/off         — Anti link grup WA
│ ${P}antilink on/off       — Anti semua link
│ ${P}antishortlink on/off  — Anti link pemendek
│ ${P}antilinkphising on/off— Anti link/pola phising
│ ${P}antispam on/off       — Anti spam pesan
│ ${P}antitoxic on/off      — Anti kata kasar
│ ${P}antijudol on/off      — Anti promosi judi online
│ ${P}antipinjol on/off     — Anti promosi pinjol ilegal
│ ${P}anticaps on/off       — Anti HURUF KAPITAL berlebihan
│ ${P}antivirtex on/off     — Anti teks virus/zalgo
│ ${P}antitag on/off        — Anti spam mention massal
│ _(Anti-flood otomatis aktif jika antispam on)_
│
│ ${P}resetprotection   — Matikan SEMUA proteksi sekaligus
│ ${P}antilinkall on/off— Semua proteksi link sekaligus
│ ${P}grouplockstatus   — Lihat status semua proteksi & lock
│ ${P}helpproteksi      — Cheatsheet ringkas semua proteksi
╰──────────────────────────────

╭─「 🔒 *LOCK KONTEN GRANULAR* 」
│ ${P}lockimage on/off    — Kunci gambar
│ ${P}lockvideo on/off    — Kunci video
│ ${P}lockdocument on/off — Kunci dokumen (.apk dll)
│ ${P}lockcontact on/off  — Kunci kontak/vCard
│ ${P}locklocation on/off — Kunci share lokasi
│ ${P}lockvn on/off       — Kunci voice note
│ ${P}lockaudio on/off    — Kunci file audio/musik
│ ${P}lockgif on/off      — Kunci GIF
│ ${P}lockpoll on/off     — Kunci polling
│ _(terpisah dari ${P}lockmedia — bisa kunci 1 jenis saja)_
╰──────────────────────────────

╭─「 📝 *KATA TERLARANG, LINK & WHITELIST* 」
│ ${P}addbadword [kata]  — Tambah kata terlarang custom
│ ${P}delbadword [kata]  — Hapus kata terlarang custom
│ ${P}listbadword        — Lihat daftar kata custom
│ ${P}allowlinkadd [dom] — Kecualikan domain dari Anti-Link
│ ${P}allowlinkdel [dom] — Hapus pengecualian domain
│ ${P}allowlinklist      — Lihat daftar domain dikecualikan
│ ${P}whitelistadd @tag  — Bebaskan member dari proteksi baru
│ ${P}whitelistdel @tag  — Hapus dari whitelist
│ ${P}whitelist          — Lihat daftar whitelist
╰──────────────────────────────

╭─「 📊 *POLL, JADWAL & LAPORAN* 」
│ ${P}poll [q]|[a]|[b] — Buat polling
│ ${P}vote [id] [no]   — Pilih jawaban poll
│ ${P}hasilpoll [id]   — Lihat hasil poll
│ ${P}listpoll         — Semua poll aktif
│ ${P}addjadwal [teks] — Tambah jadwal grup
│ ${P}listjadwal       — Lihat semua jadwal
│ ${P}deljadwal [no]   — Hapus jadwal
│ ${P}lapor [isi]      — Laporkan ke admin
│ ${P}listlaporan      — Lihat semua laporan
│ ${P}clearlaporan     — Hapus semua laporan
│ ${P}aktivitasgrup    — Statistik aktivitas
╰──────────────────────────────

╭─「 👀 *SIDER (MEMBER GAK AKTIF)* 」
│ ${P}sider [durasi]     — Cek member yg gak/jarang chat
│ ${P}kicksider [durasi] — Kick semua sider sekaligus
│ _Default durasi: 3 hari. Contoh: ${P}sider 7d_
│ _Admin grup tidak pernah dihitung sider._
╰──────────────────────────────

╭─「 📋 *FITUR LAIN* 」
│ ${P}ban @tag         — Ban user dari bot
│ ${P}unban @tag       — Unban user
│ ${P}banlist          — Lihat daftar user diblokir
│ ${P}unbanall         — Buka semua blokir sekaligus
│ ${P}autoreply [...]  — Atur auto-reply
│ ${P}notes [...]      — Catatan grup
╰──────────────────────────────

╭─「 👥➕ *MANAJEMEN MEMBER LANJUTAN* 」
│ ${P}kickall yakin    — Keluarkan SEMUA non-admin
│ ${P}warnall          — Beri warn ke SEMUA non-admin
│ ${P}cekwarnall       — Lihat semua member yg punya warn
│ ${P}topwarn          — Ranking member warn terbanyak
│ ${P}resetwarnall     — Reset semua data warn grup ini
│ ${P}mutemember @tag  — Bisukan 1 member (bukan grup)
│ ${P}unmutemember @tag— Buka bisu 1 member
│ ${P}listmutedmember  — Lihat member yang dibisukan
╰──────────────────────────────

╭─「 📥 *APPROVAL JOIN REQUEST* 」
│ _(khusus grup mode "Perlu Persetujuan Admin")_
│ ${P}listrequest         — Lihat permintaan join tertunda
│ ${P}approverequest 62xx — Terima 1 permintaan
│ ${P}rejectrequest 62xx  — Tolak 1 permintaan
│ ${P}approveall          — Terima semua sekaligus
│ ${P}rejectall           — Tolak semua sekaligus
╰──────────────────────────────

╭─「 ⏰ *JADWAL BUKA/TUTUP OTOMATIS* 」
│ ${P}jadwalbuka 07:00  — Jadwal buka grup tiap hari
│ ${P}jadwaltutup 22:00 — Jadwal tutup grup tiap hari
│ ${P}cekjadwalgrup     — Lihat jadwal aktif
│ ${P}canceljadwalgrup  — Batalkan jadwal
╰──────────────────────────────

╭─「 ⚙️➕ *KONFIGURASI GRUP LANJUTAN* 」
│ ${P}seticon        — Set foto grup (reply gambar)
│ ${P}hapusicon      — Hapus foto grup
│ ${P}lockinfo       — Kunci info grup (nama/ikon/desc)
│ ${P}unlockinfo     — Buka kunci info grup
│ ${P}ephemeral [d]  — Pesan sementara: off/1d/7d/90d
│ ${P}backupsetting  — Backup semua pengaturan grup
│ ${P}restoresetting — Kembalikan dari backup
╰──────────────────────────────

╭─「 📊 *DASHBOARD & INFO GRUP* 」
│ ${P}groupsummary   — Dashboard ringkas grup
│ ${P}groupage       — Umur grup ini
│ ${P}admincount     — Jumlah admin
│ ${P}groupcreator   — Siapa pembuat grup
│ ${P}exportmember   — Export data semua member
│ ${P}cekbot         — Cek status admin bot di grup ini
╰──────────────────────────────`
    );
}

// ─── MENU FUN ─────────────────────────────────────────────────────
export async function sendFunMenu(reply) {
    await reply(
`╔══════════════════════════════════════╗
║   🎮  *MENU FUN, GAME & HIBURAN*
╚══════════════════════════════════════╝

╭─「 🎲 *GAME KLASIK* 」
│ ${P}quote         — Kutipan motivasi acak
│ ${P}fact          — Fakta unik menarik
│ ${P}riddle        — Teka-teki (tebak jawabannya!)
│ ${P}truth         — Pertanyaan truth
│ ${P}dare          — Tantangan dare
│ ${P}pantun        — Berbalas pantun
│ ${P}coinflip      — Lempar koin
│ ${P}dice [sisi]   — Lempar dadu
│ ${P}rps [pilihan] — Batu Gunting Kertas
│ ${P}slot          — Mesin slot 🎰
│ ${P}tebakangka    — Mulai tebak angka
│ ${P}tebak [angka] — Jawab tebak angka
╰──────────────────────────────

╭─「 💕 *ROMANCE & SOSIAL* 」
│ ${P}wyr           — Would You Rather
│ ${P}jodoh @tag    — Cek kompatibilitas jodoh 💑
│ ${P}tarot         — Baca kartu tarot hari ini
│ ${P}fortunecookie — Kue keberuntungan 🍪
│ ${P}lovecalc [nm] — Kalkulator cinta
│ ${P}zodiak [tgl]  — Cek zodiak & ramalan
╰──────────────────────────────

╭─「 🧠 *MINI GAME* 」
│ ${P}trivia            — Pertanyaan trivia
│ ${P}jawabtrivia [jwb] — Jawab trivia
│ ${P}wordscramble      — Tebak kata acak
│ ${P}jawabscramble     — Jawab wordscramble
│ ${P}riddle2           — Teka-teki edisi 2
│ ${P}jawabriddle2      — Jawab teka-teki
│ ${P}guesshilo         — Game higher or lower
│ ${P}tebakhilo [n]     — Tebak higher/lower
│ ${P}tebakgambar       — Tebak gambar 🖼️
╰──────────────────────────────

╭─「 🎉 *RANDOM FUN* 」
│ ${P}dadjoke          — Lelucon bapak 😂
│ ${P}konspirasi       — Teori konspirasi lucu
│ ${P}kepribadianhariini — Kepribadian hari ini
│ ${P}katahariini      — Kata-kata of the day
│ ${P}pilihini         — This or That?
│ ${P}magic8ball [?]   — Bola kedelapan ajaib
│ ${P}ratehariini      — Rate hari ini
│ ${P}angkakeberuntungan — Angka hoki
│ ${P}emojirandom      — Emoji random
│ ${P}pengagumrahasia  — Siapa yang diam-diam suka kamu? 👀
│ ${P}afirmasihariini  — Afirmasi positif
╰──────────────────────────────

╭─「 🎭 *ROAST & PUJIAN* 」
│ ${P}roast @tag       — Sindir member (bercanda!) 😈
│ ${P}compliment @tag  — Puji member 💐
│ ${P}pujianrandom2    — Pujian random edisi 2
│ ${P}rayuan           — Kata rayuan gombal
│ ${P}pernahkah        — Never Have I Ever
│ ${P}pembukacerita    — Story starter acak
│ ${P}tantanganrandom  — Tantangan seru
╰──────────────────────────────

╭─「 🎯 *LAINNYA* 」
│ ${P}mbtitoday    — Tebak MBTI hari ini
│ ${P}nomorhoki    — Nomor keberuntunganmu
│ ${P}moodku       — Mood hari ini
│ ${P}rolldadu [n] — Roll banyak dadu sekaligus
╰──────────────────────────────

╭─「 💙 *GOJO SATORU SPECIAL* 」
│ ${P}gojo            — Kutipan random ala Gojo Satoru
│ ${P}gojoteknik      — Jurus/teknik Gojo (acak)
│ ${P}gojoroast @tag  — Diroasting ala Gojo 😏
│ ${P}gojohype @tag   — Disemangatin ala Gojo 💪
│ ${P}gojofact        — Fakta seputar Gojo Satoru
│ ${P}gojopower @tag  — Cek "power level" ala Gojo
╰──────────────────────────────`
    );
}

// ─── MENU TOOLS ───────────────────────────────────────────────────
export async function sendToolsMenu(reply) {
    await reply(
`╔══════════════════════════════════════╗
║   🛠️  *MENU TOOLS & UTILITY*
╚══════════════════════════════════════╝

╭─「 ℹ️ *INFO BOT* 」
│ ${P}pembayaran — Info pembayaran (DANA/GoPay/OVO)
│ ${P}sosmedowner — Sosial media Owner
│ ${P}owner   — Info & kontak developer
│ ${P}ping    — Cek latensi & status bot
│ ${P}whoami  — Lihat info nomormu
│ ${P}runtime — Lama bot sudah aktif
│ ${P}jam     — Waktu server sekarang
╰──────────────────────────────

╭─「 🔤 *MANIPULASI TEKS* 」
│ ${P}upper [teks]     — HURUF BESAR SEMUA
│ ${P}lower [teks]     — huruf kecil semua
│ ${P}reverse [teks]   — sket terbalik
│ ${P}alternating      — HuRuF SeLaNg-SeLiNg
│ ${P}titlecase [teks] — Setiap Kata Kapital
│ ${P}camelcase        — camelCaseFormat
│ ${P}snakecase        — snake_case_format
│ ${P}kebabcase        — kebab-case-format
│ ${P}leet [teks]      — l337 sp34k
│ ${P}rot13 [teks]     — ROT13 cipher
│ ${P}wordcount [teks] — Hitung jumlah kata
│ ${P}hitungvokal      — Hitung huruf vokal
│ ${P}hitungkonsonan   — Hitung konsonan
│ ${P}hapusvokal       — Hapus semua vokal
│ ${P}ulangteks [n]    — Ulangi teks N kali
│ ${P}frekuensikata    — Frekuensi tiap kata
╰──────────────────────────────

╭─「 🔐 *ENKRIPSI & ENCODING* 」
│ ${P}tobinary [txt]   — Teks → Binary
│ ${P}frombinary [bin] — Binary → Teks
│ ${P}tobase64 [txt]   — Teks → Base64
│ ${P}frombase64 [b64] — Base64 → Teks
│ ${P}tohex [txt]      — Teks → Hexadecimal
│ ${P}fromhex [hex]    — Hex → Teks
│ ${P}tomorse [txt]    — Teks → Morse Code
│ ${P}frommorse [...]  — Morse → Teks
│ ${P}caesarenkrip [n] — Caesar cipher encrypt
│ ${P}caesardekrip [n] — Caesar cipher decrypt
│ ${P}textascii [txt]  — Teks → ASCII codes
│ ${P}asciitext [...]  — ASCII → Teks
╰──────────────────────────────

╭─「 🔢 *MATEMATIKA* 」
│ ${P}calc [expr]      — Kalkulator pintar
│ ${P}persen [a] [b]   — Hitung persentase
│ ${P}persenubah [a][b]— Perubahan persentase
│ ${P}bmi [kg] [cm]    — Hitung BMI
│ ${P}bmidetail        — BMI detail lengkap
│ ${P}umur [YYYY-MM-DD]— Hitung usia
│ ${P}cekprima [n]     — Cek bilangan prima
│ ${P}faktorial [n]    — Hitung faktorial
│ ${P}fibonacci [n]    — Deret Fibonacci
│ ${P}gcdlcm [a] [b]   — FPB dan KPK
│ ${P}roman [n]        — Angka → Romawi
│ ${P}kuadrat [a][b][c]— Rumus kuadrat
│ ${P}average [...]    — Rata-rata angka
│ ${P}median [...]     — Nilai median
╰──────────────────────────────

╭─「 📐 *KONVERSI* 」
│ ${P}convertlength    — Konversi panjang
│ ${P}convertweight    — Konversi berat
│ ${P}suhu [n] [mode]  — Konversi suhu
│   _(c2f / f2c / c2k / k2c)_
│ ${P}suhulengkap [n]  — Konversi ke semua
╰──────────────────────────────

╭─「 💸 *KEUANGAN* 」
│ ${P}diskon [harga]%  — Hitung diskon
│ ${P}splitbill [..][n]— Bagi tagihan rata
│ ${P}hitungtip [bill] — Hitung tip (%)
╰──────────────────────────────

╭─「 ✅ *VALIDATOR* 」
│ ${P}cekpalindrom     — Cek palindrom
│ ${P}cekemail [email] — Validasi email
│ ${P}ceknohp [nomor]  — Validasi no HP
│ ${P}cekcc [nomor]    — Cek kartu kredit
│ ${P}cekpassword [pw] — Kekuatan password
╰──────────────────────────────

╭─「 🎲 *GENERATOR RANDOM* 」
│ ${P}genpassword [n]  — Generate password kuat
│ ${P}genuuid          — Generate UUID
│ ${P}pilih a, b, c    — Pilih secara random
│ ${P}shuffle a, b, c  — Acak urutan item
│ ${P}warnarandom      — Warna HEX random
│ ${P}tanggalrandom    — Tanggal random
╰──────────────────────────────

╭─「 📅 *TANGGAL & WAKTU* 」
│ ${P}harike [tanggal]  — Hari dalam minggu
│ ${P}sisahari [tgl]    — Hitung sisa hari
│ ${P}leapyear [tahun]  — Cek tahun kabisat
│ ${P}zodiaklahir [tgl] — Zodiak dari tgl lahir
╰──────────────────────────────`
    );
}

// ─── MENU MEDIA ───────────────────────────────────────────────────
export async function sendMediaMenu(reply) {
    await reply(
`╔══════════════════════════════════════╗
║   🖼️  *MENU MEDIA*
╚══════════════════════════════════════╝

╭─「 🎵 *MUSIK YOUTUBE* 」
│ ${P}play <judul>   — Cari & kirim audio dari YouTube
│ _Contoh: \`${P}play Naruto opening\`_
╰──────────────────────────────

╭─「 📥 *DOWNLOAD SOSIAL MEDIA* 」
│ ${P}ig <link>      — Download video Instagram (reel/post)
│ ${P}tiktok <link>  — Download video TikTok
│ _Bisa juga REPLY ke pesan yang isinya link, lalu ketik command-nya_
╰──────────────────────────────

╭─「 📤 *REPOST MEDIA* 」
│ ${P}repost    — Kirim ulang media terakhir
│ ${P}mediainfo — Info media terakhir di chat
╰──────────────────────────────

╭─「 🎭 *STIKER* 」
│ ${P}sticker  — Cara membuat stiker WA
│ _Kirim gambar/video dengan caption_
│ \`${P}sticker\` untuk konversi otomatis
╰──────────────────────────────

╭─「 📸 *FOTO PROFIL* 」
│ ${P}pp [@tag]  — Lihat foto profil member
│ ${P}ppgrup     — Lihat foto profil grup
╰──────────────────────────────

╭─「 🟢 *BRAT & IQC* 」
│ ${P}brat <teks>        — Gambar teks ala "brat"
│ \`${P}iqc <teks> dark\` — Versi tema gelap
│ _Bisa juga reply pesan teks lalu ketik command-nya_
╰──────────────────────────────

💡 _Fitur media terus berkembang!_
_Update bot secara berkala untuk fitur baru._`
    );
}

// ─── MENU BOT ─────────────────────────────────────────────────────
export async function sendBotMenu(reply) {
    await reply(
`╔══════════════════════════════════════╗
║   🤖  *MENU BOT — OWNER CONTROL*
╚══════════════════════════════════════╝

╭─「 📦 *INFO FITUR* 」
│ ${P}totalfitur   — Jumlah total command/fitur bot
│ ${P}allmenu      — Lihat semua command lengkap
╰──────────────────────────────

╭─「 📢 *BROADCAST* 」
│ ${P}broadcast [pesan]     — Kirim ke semua grup
│ ${P}broadcastuser [pesan] — Kirim ke semua user RPG
│ ${P}listgrup              — Lihat jumlah grup bot
│ _⚠️ Khusus owner saja_
╰──────────────────────────────

╭─「 🔄 *JADIBOT (MULTI-DEVICE)* 」
│ ${P}jadibot [628xxx]  — Pasang bot di nomor lain
│ ${P}stopbot [628xxx]  — Hentikan jadibot
│ ${P}listjadibot       — Daftar jadibot aktif
╰──────────────────────────────

╭─「 ℹ️ *CATATAN PENTING* 」
│ ◈ Setiap jadibot = koneksi WA terpisah
│ ◈ Max ${20} jadibot aktif bersamaan
│ ◈ Risiko ban nomor jadibot ditanggung user
│ ◈ Gunakan dengan bijak!
╰──────────────────────────────`
    );
}
